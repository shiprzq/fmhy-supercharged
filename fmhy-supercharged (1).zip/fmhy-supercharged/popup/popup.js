/**
 * FMHY Supercharged — Popup script
 * Manages the 4-tab popup UI: Quick, Bookmarks, Recent, Settings.
 */
(function () {
  "use strict";

  const NS = "fmhy_sc_";
  const DEFAULTS_SETTINGS = {
    base64Decoder: true, commandPalette: true, bookmarks: true, sync: false,
    healthChecker: true, notes: true, diffViewer: true, safetyBadges: true,
    filters: true, miniToc: true, recentHistory: true, quickToolbar: true,
    radialMenu: true, relatedSidebar: true, keyboardNav: true, searchEnhancer: true,
    themeSwitcher: true, densityModes: true, scrollMemory: true, highlightRules: true,
    readingMode: true, compareMatrix: true, ratings: true, watchedNotifications: true,
    notifications: true, exportTools: true, shareCards: true, density: "comfortable"
  };

  const FEATURE_LABELS = {
    base64Decoder: "Base64 auto-decoder",
    commandPalette: "Command palette (Ctrl+Shift+K)",
    bookmarks: "Bookmark manager",
    sync: "Cross-device sync",
    healthChecker: "Dead-link monitor",
    notes: "Inline notes",
    diffViewer: "What's-new diff",
    safetyBadges: "Safety & trust badges",
    filters: "Smart filters bar",
    miniToc: "Mini table of contents",
    recentHistory: "Recently viewed tracking",
    quickToolbar: "Quick-access toolbar",
    radialMenu: "Radial category menu",
    relatedSidebar: "Related resources panel",
    keyboardNav: "Vim keyboard nav",
    searchEnhancer: "Search autocomplete",
    themeSwitcher: "Per-category themes",
    densityModes: "Density modes",
    scrollMemory: "Scroll memory",
    highlightRules: "Highlight rules",
    readingMode: "Reading mode",
    compareMatrix: "Comparison matrix",
    ratings: "Star ratings",
    watchedNotifications: "Watched categories",
    notifications: "Desktop notifications",
    exportTools: "Export tools",
    shareCards: "Shareable cards"
  };

  function get(k) {
    return new Promise((r) => chrome.storage.local.get([NS + k], (res) => r(res[NS + k] ?? DEFAULTS_SETTINGS[k])));
  }
  function set(k, v) {
    return new Promise((r) => {
      const settings = {};
      chrome.storage.local.get([NS + "settings"], (cur) => {
        const merged = { ...(cur[NS + "settings"] || DEFAULTS_SETTINGS), [k]: v };
        const obj = {};
        obj[NS + "settings"] = merged;
        chrome.storage.local.set(obj, () => r());
      });
    });
  }

  function getRaw(k) {
    return new Promise((r) => chrome.storage.local.get([NS + k], (res) => r(res[NS + k] ?? null)));
  }

  // ---------- Tab switching ----------
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
      tab.classList.add("active");
      document.querySelector(`.tab-panel[data-panel="${tab.dataset.tab}"]`).classList.add("active");
      if (tab.dataset.tab === "bookmarks") renderBookmarks();
      if (tab.dataset.tab === "history") renderHistory();
      if (tab.dataset.tab === "settings") renderToggles();
    });
  });

  // ---------- Quick actions ----------
  document.getElementById("open-palette").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { type: "openCommandPalette" });
    window.close();
  });

  document.getElementById("open-radial").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { type: "openRadialMenu" });
    window.close();
  });

  document.getElementById("action-export").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { type: "exportData" });
    window.close();
  });

  document.getElementById("action-sync").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "syncNow" }, (res) => {
      const el = document.getElementById("sync-status");
      if (res && res.ok) el.textContent = "✓ Synced";
      else el.textContent = "⚠ Sync failed (configure in Options)";
      setTimeout(() => el.textContent = "", 3000);
    });
  });

  document.getElementById("action-bookmark-page").addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) chrome.tabs.sendMessage(tab.id, { type: "toggleBookmarkCurrent" });
    window.close();
  });

  document.getElementById("action-options").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  document.getElementById("open-options-page").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  document.getElementById("clear-history").addEventListener("click", async () => {
    if (!confirm("Clear all recently-viewed history?")) return;
    await new Promise((r) => {
      const obj = {}; obj[NS + "recentHistory"] = [];
      chrome.storage.local.set(obj, r);
    });
    renderHistory();
  });

  // ---------- Bookmarks ----------
  async function renderBookmarks() {
    const list = document.getElementById("bm-list");
    const search = document.getElementById("bm-search");
    const all = (await getRaw("bookmarks")) || [];
    document.getElementById("bm-count").textContent = all.length;

    const render = (filter) => {
      const f = (filter || "").toLowerCase().trim();
      const items = f
        ? all.filter((b) => b.title.toLowerCase().includes(f) || b.url.toLowerCase().includes(f) || (b.tags || []).some((t) => t.toLowerCase().includes(f)))
        : all;
      list.innerHTML = "";
      if (items.length === 0) {
        list.innerHTML = `<div class="empty"><span class="empty-icon">🔖</span>${all.length === 0 ? "No bookmarks yet.<br>Click the ＋ button next to any resource on fmhy.net." : "No matches found."}</div>`;
        return;
      }
      items.slice(0, 50).forEach((bm) => {
        const item = document.createElement("div");
        item.className = "bm-item";
        const host = (() => { try { return new URL(bm.url).hostname; } catch (e) { return ""; } })();
        const fav = host ? `https://www.google.com/s2/favicons?sz=32&domain=${host}` : "";
        item.innerHTML = `
          ${fav ? `<img class="bm-item-icon" src="${fav}" alt="" width="20" height="20" onerror="this.style.visibility='hidden';this.nextElementSibling.style.display='inline'"><span class="bm-item-icon" style="display:none;font-size:14px">🔖</span>` : `<span class="bm-item-icon">🔖</span>`}
          <div class="bm-item-body">
            <div class="bm-item-title"></div>
            <div class="bm-item-sub">${bm.category || "uncategorized"} · ${host || "unknown"}</div>
          </div>
          <button class="bm-item-delete" title="Delete bookmark">✕</button>
        `;
        item.querySelector(".bm-item-title").textContent = bm.title;
        item.addEventListener("click", (e) => {
          if (e.target.classList.contains("bm-item-delete")) return;
          chrome.tabs.create({ url: bm.url });
        });
        item.querySelector(".bm-item-delete").addEventListener("click", async (e) => {
          e.stopPropagation();
          await new Promise((r) => {
            chrome.storage.local.get([NS + "bookmarks"], (res) => {
              const arr = res[NS + "bookmarks"] || [];
              const next = arr.filter((b) => b.id !== bm.id);
              const obj = {};
              obj[NS + "bookmarks"] = next;
              chrome.storage.local.set(obj, r);
            });
          });
          renderBookmarks();
        });
        list.appendChild(item);
      });
    };

    render("");
    search.oninput = () => render(search.value);
  }

  // ---------- History ----------
  async function renderHistory() {
    const list = document.getElementById("history-list");
    const hist = (await getRaw("recentHistory")) || [];
    if (hist.length === 0) {
      list.innerHTML = `<div class="empty"><span class="empty-icon">🕑</span>No recently viewed resources yet.</div>`;
      return;
    }
    list.innerHTML = "";
    hist.slice(0, 20).forEach((h) => {
      const item = document.createElement("div");
      item.className = "history-item";
      const host = (() => { try { return new URL(h.url).hostname; } catch (e) { return ""; } })();
      const ago = timeAgo(h.visitedAt);
      const fav = host ? `https://www.google.com/s2/favicons?sz=32&domain=${host}` : "";
      item.innerHTML = `
        ${fav ? `<img class="history-item-icon" src="${fav}" alt="" width="20" height="20" onerror="this.style.visibility='hidden';this.nextElementSibling.style.display='inline'"><span class="history-item-icon" style="display:none">🕑</span>` : `<span class="history-item-icon">🕑</span>`}
        <div class="history-item-body">
          <div class="history-item-title"></div>
          <div class="history-item-sub">${ago} · ${host || "unknown"}</div>
        </div>
      `;
      item.querySelector(".history-item-title").textContent = h.title || h.url;
      item.addEventListener("click", () => chrome.tabs.create({ url: h.url }));
      list.appendChild(item);
    });
  }

  function timeAgo(ts) {
    if (!ts) return "never";
    const s = Math.floor((Date.now() - ts) / 1000);
    if (s < 60) return "just now";
    const m = Math.floor(s / 60);
    if (m < 60) return m + "m ago";
    const h = Math.floor(m / 60);
    if (h < 24) return h + "h ago";
    return Math.floor(h / 24) + "d ago";
  }

  // ---------- Sync status ----------
  async function showSyncStatus() {
    const cfg = await getRaw("syncConfig");
    const el = document.getElementById("sync-status");
    if (!el) return;
    const dot = el.querySelector(".status-dot");
    const text = el.querySelector(".status-text");
    if (!cfg || cfg.provider === "none") {
      if (dot) dot.style.background = "#94a3b8";
      if (text) text.textContent = "Sync not configured — set up in Options";
    } else {
      const last = cfg.lastSync ? timeAgo(cfg.lastSync) : "never";
      if (dot) dot.style.background = "#22c55e";
      if (text) text.textContent = `Synced via ${cfg.provider === "gist" ? "GitHub Gist" : "WebDAV"} · ${last}`;
    }
  }

  // ---------- Settings toggles ----------
  async function renderToggles() {
    const container = document.getElementById("feature-toggles");
    const settings = (await getRaw("settings")) || DEFAULTS_SETTINGS;
    container.innerHTML = "";
    Object.keys(FEATURE_LABELS).forEach((key) => {
      const row = document.createElement("div");
      row.className = "toggle-row";
      const isOn = settings[key] !== false;
      row.innerHTML = `<label>${FEATURE_LABELS[key]}</label><div class="toggle ${isOn ? "on" : ""}"></div>`;
      const tog = row.querySelector(".toggle");
      tog.addEventListener("click", async () => {
        const newVal = !(await get(key));
        await set(key, newVal);
        tog.classList.toggle("on", newVal);
      });
      container.appendChild(row);
    });
  }

  // Initial render
  showSyncStatus();
  (async () => {
    const bms = (await getRaw("bookmarks")) || [];
    document.getElementById("bm-count").textContent = bms.length;
  })();
})();
