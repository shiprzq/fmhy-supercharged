/**
 * FMHY Supercharged — Custom Resource Highlighting Rules
 * =====================================================================
 *
 * Improved version:
 *   - Multiple highlights per link (every matching rule gets a pill)
 *   - More stable: uses a data attribute to track which pills we added
 *     so re-running doesn't duplicate or lose pills
 *   - Highlights both link text AND URL
 *   - Pills are styled as small color-coded tags after the link
 *
 * Default rules:
 *   open-source   → green
 *   self-host     → purple
 *   freemium      → yellow
 *
 * @module FMHY.highlightRules
 */
(function (global) {
  "use strict";
  global.FMHY = global.FMHY || {};

  const NAME = "highlightRules";
  let initialized = false;
  let rules = [];

  /**
   * Load rules from storage.
   */
  async function loadRules() {
    rules = await FMHY.Storage.getHighlightRules();
    // Filter out invalid rules
    rules = rules.filter((r) => r && r.pattern);
  }

  /**
   * Apply highlights to all resource links.
   * Each link can have MULTIPLE highlight pills (one per matching rule).
   * Uses data-fmhy-highlighted attribute to track which pills we added,
   * so re-running is idempotent (no duplicates).
   */
  function applyHighlights() {
    if (!rules || rules.length === 0) return;
    const links = FMHY.Dom.getResourceLinks();

    links.forEach(({ element, text, href }) => {
      // Remove only our previously-added pills (identified by data attribute)
      const oldPills = element.querySelectorAll(".fmhy-highlight-pill[data-fmhy-rule]");
      oldPills.forEach((p) => p.remove());
      element.classList.remove("fmhy-highlighted");

      // Track which rules matched (to avoid duplicate pills for the same rule)
      const matchedRules = new Set();

      // Test each rule against both text and URL
      for (const rule of rules) {
        if (matchedRules.has(rule.id)) continue;
        try {
          const re = new RegExp(rule.pattern, "i");
          if (re.test(text) || re.test(href)) {
            element.classList.add("fmhy-highlighted");
            const pill = FMHY.Dom.el("span", {
              class: "fmhy-highlight-pill",
              "data-fmhy-rule": rule.id,
              style: { background: rule.color },
              title: `Matched: ${rule.label || rule.pattern}`
            }, rule.label || "");
            element.appendChild(pill);
            matchedRules.add(rule.id);
          }
        } catch (e) {
          // Skip invalid regex silently
        }
      }
    });
  }

  /**
   * Remove all highlight pills from the page.
   */
  function removeAll() {
    document.querySelectorAll(".fmhy-highlight-pill[data-fmhy-rule]").forEach((p) => p.remove());
    document.querySelectorAll(".fmhy-highlighted").forEach((el) => el.classList.remove("fmhy-highlighted"));
  }

  global.FMHY.registerFeature(NAME, {
    init() {
      if (initialized) return;
      initialized = true;
      loadRules().then(applyHighlights);
      FMHY.onPageChange(() => {
        loadRules().then(applyHighlights);
      });
    },
    onMessage() { return false; },
    refresh: () => loadRules().then(applyHighlights),
    removeAll
  });

})(typeof globalThis !== "undefined" ? globalThis : (typeof self !== "undefined" ? self : this));
