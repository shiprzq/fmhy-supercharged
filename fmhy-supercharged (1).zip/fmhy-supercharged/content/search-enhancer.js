/**
 * FMHY Supercharged — Enhanced Search with Toggle + Autocomplete + Advanced
 * =====================================================================
 *
 * Adds a small toggle icon next to fmhy.net's search bar. When enabled:
 *
 *   1. AUTOCOMPLETE — as the user types, show matching resources from:
 *      - All links on the current page (partial word match)
 *      - All bookmarks
 *      - All recently-viewed history
 *      - All page headings
 *      Clicking a result navigates to it.
 *
 *   2. ADVANCED SEARCH — a popover with filters:
 *      - Search in: Current page / All bookmarks / History
 *      - Filter by: Category / Tag / Trust level
 *      - Sort by: Relevance / Recently added / Alphabetical
 *      - Match type: Partial word / Prefix / Exact
 *
 * The toggle persists in storage so it stays on across sessions.
 *
 * @module FMHY.searchEnhancer
 */
(function (global) {
  "use strict";
  global.FMHY = global.FMHY || {};

  const NAME = "searchEnhancer";
  let initialized = false;
  let dropdown = null;
  let advancedPanel = null;
  let activeIdx = 0;
  let currentResults = [];

  /** Advanced search state. */
  const advanced = {
    enabled: false,
    searchIn: "all",      // all | page | bookmarks | history
    category: "",         // empty = any
    tag: "",              // empty = any
    trust: "all",         // all | safe | paid | account | ads | unknown
    sortBy: "relevance",  // relevance | recent | alpha
    matchType: "partial"  // partial | prefix | exact
  };

  /** Cached data for fast autocomplete. */
  let pageLinksCache = [];
  let bookmarksCache = [];
  let historyCache = [];
  let headingsCache = [];

  /**
   * Find VitePress search inputs on the page.
   */
  function findSearchInputs() {
    return document.querySelectorAll(
      'input[type="search"], input[placeholder*="search" i], .DocSearch-Input, .VPNavBarSearch input, .VPNavBarSearch > div'
    );
  }

  /**
   * Attach the toggle icon + autocomplete to a search input.
   */
  function attach(input) {
    if (input.dataset.fmhySearchEnh) return;
    input.dataset.fmhySearchEnh = "1";

    // Insert toggle icon next to the input
    const wrapper = input.parentElement;
    if (wrapper && !wrapper.querySelector(".fmhy-sc-search-toggle")) {
      const toggle = FMHY.Dom.el("button", {
        class: "fmhy-sc-search-toggle",
        "aria-label": "Toggle FMHY Supercharged search",
        title: "FMHY Supercharged search — click to enable autocomplete & advanced search",
        type: "button"
      });
      toggle.appendChild(FMHY.Icon.render("zap", 14));
      toggle.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleAdvanced(toggle);
      });
      wrapper.style.position = "relative";
      wrapper.appendChild(toggle);

      // Load persisted state
      FMHY.Storage.getSetting("searchEnhancerEnabled").then((enabled) => {
        if (enabled) {
          toggle.classList.add("active");
        }
      });
    }

    // Wire up input events
    input.addEventListener("input", FMHY.Dom.debounce(() => onInput(input), 120));
    input.addEventListener("focus", () => onInput(input));
    input.addEventListener("blur", () => setTimeout(closeDropdown, 250));
    input.addEventListener("keydown", (e) => onKeydown(e, input));
  }

  /**
   * Toggle the advanced search panel open/closed.
   */
  function toggleAdvanced(toggleBtn) {
    if (advancedPanel) {
      closeAdvanced();
      return;
    }
    openAdvanced(toggleBtn);
  }

  /**
   * Open the advanced search panel.
   */
  async function openAdvanced(toggleBtn) {
    closeAdvanced();
    advancedPanel = FMHY.Dom.el("div", {
      class: "fmhy-sc-search-advanced",
      role: "dialog",
      "aria-label": "Advanced search options"
    });

    // Header
    const header = FMHY.Dom.el("div", { class: "fmhy-sc-search-advanced-header" });
    header.appendChild(FMHY.Dom.el("span", { class: "fmhy-sc-search-advanced-title" }, "Advanced Search"));
    const closeBtn = FMHY.Dom.el("button", { class: "fmhy-sc-search-advanced-close", "aria-label": "Close" });
    closeBtn.appendChild(FMHY.Icon.render("close", 14));
    closeBtn.addEventListener("click", closeAdvanced);
    header.appendChild(closeBtn);
    advancedPanel.appendChild(header);

    // Search in
    const searchInRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    searchInRow.appendChild(FMHY.Dom.el("label", {}, "Search in"));
    const searchInSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "all", l: "All (page + bookmarks + history)" },
      { v: "page", l: "Current page only" },
      { v: "bookmarks", l: "Bookmarks only" },
      { v: "history", l: "Recently viewed only" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.searchIn === o.v) opt.selected = true;
      searchInSelect.appendChild(opt);
    });
    searchInSelect.addEventListener("change", (e) => { advanced.searchIn = e.target.value; });
    searchInRow.appendChild(searchInSelect);
    advancedPanel.appendChild(searchInRow);

    // Match type
    const matchRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    matchRow.appendChild(FMHY.Dom.el("label", {}, "Match type"));
    const matchSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "partial", l: "Partial word (contains)" },
      { v: "prefix", l: "Prefix (starts with)" },
      { v: "exact", l: "Exact match" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.matchType === o.v) opt.selected = true;
      matchSelect.appendChild(opt);
    });
    matchSelect.addEventListener("change", (e) => { advanced.matchType = e.target.value; });
    matchRow.appendChild(matchSelect);
    advancedPanel.appendChild(matchRow);

    // Trust filter
    const trustRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    trustRow.appendChild(FMHY.Dom.el("label", {}, "Trust level"));
    const trustSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "all", l: "Any trust level" },
      { v: "safe", l: "Trusted (open-source)" },
      { v: "unknown", l: "Unknown" },
      { v: "paid", l: "May require payment" },
      { v: "account", l: "May require account" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.trust === o.v) opt.selected = true;
      trustSelect.appendChild(opt);
    });
    trustSelect.addEventListener("change", (e) => { advanced.trust = e.target.value; });
    trustRow.appendChild(trustSelect);
    advancedPanel.appendChild(trustRow);

    // Sort by
    const sortRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    sortRow.appendChild(FMHY.Dom.el("label", {}, "Sort by"));
    const sortSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "relevance", l: "Relevance" },
      { v: "recent", l: "Recently added" },
      { v: "alpha", l: "Alphabetical (A-Z)" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.sortBy === o.v) opt.selected = true;
      sortSelect.appendChild(opt);
    });
    sortSelect.addEventListener("change", (e) => { advanced.sortBy = e.target.value; });
    sortRow.appendChild(sortSelect);
    advancedPanel.appendChild(sortRow);

    // Category + tag inputs
    const catRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    catRow.appendChild(FMHY.Dom.el("label", {}, "Category (optional)"));
    const catInput = FMHY.Dom.el("input", {
      type: "text",
      class: "fmhy-sc-adv-input",
      placeholder: "e.g. ai, storage, torrenting",
      value: advanced.category
    });
    catInput.addEventListener("input", (e) => { advanced.category = e.target.value.trim().toLowerCase(); });
    catRow.appendChild(catInput);
    advancedPanel.appendChild(catRow);

    const tagRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    tagRow.appendChild(FMHY.Dom.el("label", {}, "Tag (optional)"));
    const tagInput = FMHY.Dom.el("input", {
      type: "text",
      class: "fmhy-sc-adv-input",
      placeholder: "e.g. self-hosted, open-source",
      value: advanced.tag
    });
    tagInput.addEventListener("input", (e) => { advanced.tag = e.target.value.trim().toLowerCase(); });
    tagRow.appendChild(tagInput);
    advancedPanel.appendChild(tagRow);

    // Apply button
    const applyBtn = FMHY.Dom.el("button", { class: "fmhy-sc-btn fmhy-sc-btn-primary fmhy-sc-adv-apply" }, "Apply & Enable");
    applyBtn.addEventListener("click", async () => {
      advanced.enabled = true;
      await FMHY.Storage.setSetting("searchEnhancerEnabled", true);
      if (toggleBtn) toggleBtn.classList.add("active");
      closeAdvanced();
      showToast("Advanced search enabled — start typing in the search bar", "success");
      // Re-trigger autocomplete on the active search input
      const inputs = findSearchInputs();
      if (inputs.length > 0) onInput(inputs[0]);
      // Re-render the sidebar so the item shows as active
      const sb = FMHY.getFeature("sidebar");
      if (sb && sb.refresh) sb.refresh();
    });
    advancedPanel.appendChild(applyBtn);

    // Disable button (if already enabled)
    const isEnabledNow = await isEnabled();
    if (isEnabledNow) {
      const disableBtn = FMHY.Dom.el("button", { class: "fmhy-sc-btn fmhy-sc-btn-danger fmhy-sc-adv-disable" }, "Disable Enhanced Search");
      disableBtn.addEventListener("click", async () => {
        await FMHY.Storage.setSetting("searchEnhancerEnabled", false);
        if (toggleBtn) toggleBtn.classList.remove("active");
        closeAdvanced();
        closeDropdown();
        showToast("Enhanced search disabled", "info");
        const sb = FMHY.getFeature("sidebar");
        if (sb && sb.refresh) sb.refresh();
      });
      advancedPanel.appendChild(disableBtn);
    }

    document.body.appendChild(advancedPanel);
    positionAdvanced(toggleBtn);

    // Close on outside click
    setTimeout(() => {
      document.addEventListener("click", onAdvancedOutsideClick);
    }, 0);
  }

  function closeAdvanced() {
    if (advancedPanel) {
      advancedPanel.remove();
      advancedPanel = null;
    }
    document.removeEventListener("click", onAdvancedOutsideClick);
  }

  function onAdvancedOutsideClick(e) {
    if (advancedPanel && !advancedPanel.contains(e.target) && !e.target.classList.contains("fmhy-sc-search-toggle")) {
      closeAdvanced();
    }
  }

  function positionAdvanced(toggleBtn) {
    if (!advancedPanel || !toggleBtn) return;
    const r = toggleBtn.getBoundingClientRect();
    const panelW = 320;
    let left = r.left + window.scrollX + r.width + 4;
    let top = r.top + window.scrollY;
    if (left + panelW > window.innerWidth) {
      left = r.left + window.scrollX - panelW - 4;
    }
    advancedPanel.style.left = left + "px";
    advancedPanel.style.top = top + "px";
  }

  /**
   * Refresh cached data (page links, bookmarks, history, headings).
   */
  async function refreshCache() {
    pageLinksCache = FMHY.Dom.getResourceLinks().map((l) => ({
      type: "page-link",
      title: l.text,
      subtitle: `On this page · ${hostnameOf(l.href)}`,
      url: l.href,
      category: FMHY.Dom.getCurrentCategory(),
      tags: []
    }));

    headingsCache = [];
    document.querySelectorAll("main h2, main h3, .vp-doc h2, .vp-doc h3, article h2, article h3").forEach((h) => {
      if (!h.id) h.id = "fmhy-heading-" + Math.random().toString(36).slice(2, 8);
      headingsCache.push({
        type: "heading",
        title: h.textContent.trim(),
        subtitle: "Section on this page",
        url: "#" + h.id,
        category: FMHY.Dom.getCurrentCategory(),
        tags: []
      });
    });

    const [bms, hist] = await Promise.all([
      FMHY.Storage.getBookmarks(),
      FMHY.Storage.getHistory()
    ]);
    bookmarksCache = bms.map((b) => ({
      type: "bookmark",
      title: b.title,
      subtitle: `Bookmark · ${b.category || "uncategorized"}`,
      url: b.url,
      category: b.category || "",
      tags: b.tags || [],
      addedAt: b.addedAt || 0
    }));
    historyCache = hist.map((h) => ({
      type: "history",
      title: h.title || h.url,
      subtitle: `Recent · ${FMHY.Dom.timeAgo(h.visitedAt)}`,
      url: h.url,
      category: h.category || "",
      tags: [],
      addedAt: h.visitedAt || 0
    }));
  }

  function hostnameOf(url) {
    try { return new URL(url).hostname; } catch (e) { return ""; }
  }

  /**
   * Check if search enhancer is enabled (toggle on).
   */
  async function isEnabled() {
    return await FMHY.Storage.getSetting("searchEnhancerEnabled");
  }

  /**
   * Handle input in the search box.
   */
  async function onInput(input) {
    const enabled = await isEnabled();
    if (!enabled) { closeDropdown(); return; }

    const q = input.value.trim();
    if (!q) { closeDropdown(); return; }

    await refreshCache();
    const results = gatherResults(q);
    if (results.length === 0) {
      showNoResults(q);
      return;
    }
    showDropdown(input, results);
  }

  /**
   * Gather search results based on the query + advanced filters.
   */
  function gatherResults(q) {
    let pool = [];
    if (advanced.searchIn === "all" || advanced.searchIn === "page") {
      pool = pool.concat(pageLinksCache, headingsCache);
    }
    if (advanced.searchIn === "all" || advanced.searchIn === "bookmarks") {
      pool = pool.concat(bookmarksCache);
    }
    if (advanced.searchIn === "all" || advanced.searchIn === "history") {
      pool = pool.concat(historyCache);
    }

    // Filter by query (match type)
    const ql = q.toLowerCase();
    const matches = (text) => {
      if (!text) return false;
      const t = text.toLowerCase();
      if (advanced.matchType === "exact") return t === ql;
      if (advanced.matchType === "prefix") return t.startsWith(ql);
      return t.includes(ql); // partial
    };

    let results = pool.filter((item) => matches(item.title) || matches(item.url));

    // Filter by category
    if (advanced.category) {
      results = results.filter((i) => i.category && i.category.toLowerCase().includes(advanced.category));
    }

    // Filter by tag
    if (advanced.tag) {
      results = results.filter((i) => (i.tags || []).some((t) => t.toLowerCase().includes(advanced.tag)));
    }

    // Filter by trust
    if (advanced.trust !== "all") {
      results = results.filter((i) => {
        const trust = classifyTrust(i.title);
        return trust.level === advanced.trust;
      });
    }

    // Score + sort
    results = results.map((item) => {
      const titleLower = item.title.toLowerCase();
      let score = 0;
      if (titleLower === ql) score += 100;
      else if (titleLower.startsWith(ql)) score += 60;
      else if (titleLower.includes(ql)) score += 30;
      // Word-boundary partial match bonus
      const words = titleLower.split(/[\s\-_/.]+/);
      if (words.some((w) => w.includes(ql))) score += 20;
      return { ...item, score };
    });

    if (advanced.sortBy === "recent") {
      results.sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
    } else if (advanced.sortBy === "alpha") {
      results.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    } else {
      results.sort((a, b) => b.score - a.score);
    }

    return results.slice(0, 10);
  }

  function classifyTrust(text) {
    const t = (text || "").toLowerCase();
    const SAFE = ["open source", "open-source", "github", "gitlab", "self-hosted", "selfhost", "no ads", "ad-free"];
    const PAID = ["premium", "subscribe", "subscription", "pricing"];
    const ACCOUNT = ["sign up", "register", "log in", "login", "create account"];
    if (SAFE.some((k) => t.includes(k))) return { level: "safe" };
    if (PAID.some((k) => t.includes(k))) return { level: "paid" };
    if (ACCOUNT.some((k) => t.includes(k))) return { level: "account" };
    return { level: "unknown" };
  }

  /**
   * Show "no results" message.
   */
  function showNoResults(query) {
    closeDropdown();
    dropdown = FMHY.Dom.el("div", { class: "fmhy-sc-search-dropdown" });
    const empty = FMHY.Dom.el("div", { class: "fmhy-sc-search-empty" });
    empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-empty-icon" }));
    FMHY.Icon.inject(empty.querySelector(".fmhy-sc-search-empty-icon"), "search", 24);
    empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-empty-text" }, `No matches for "${query}"`));
    dropdown.appendChild(empty);
    positionDropdown();
    document.body.appendChild(dropdown);
  }

  /**
   * Show the autocomplete dropdown.
   */
  function showDropdown(input, results) {
    closeDropdown();
    currentResults = results;
    activeIdx = 0;
    dropdown = FMHY.Dom.el("div", { class: "fmhy-sc-search-dropdown" });

    if (results.length === 0) {
      dropdown.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-empty" }, "No matches"));
      positionDropdown(input);
      document.body.appendChild(dropdown);
      return;
    }

    results.forEach((item, idx) => {
      const row = FMHY.Dom.el("div", {
        class: "fmhy-sc-search-row" + (idx === 0 ? " active" : ""),
        "data-idx": idx
      });
      // Icon based on type
      const iconWrap = FMHY.Dom.el("span", { class: "fmhy-sc-search-row-icon" });
      const iconName = item.type === "bookmark" ? "bookmark"
        : item.type === "history" ? "history"
        : item.type === "heading" ? "list"
        : "link";
      FMHY.Icon.inject(iconWrap, iconName, 16);
      row.appendChild(iconWrap);
      // Body
      const body = FMHY.Dom.el("div", { class: "fmhy-sc-search-row-body" });
      // Highlight matched text
      const titleEl = FMHY.Dom.el("div", { class: "fmhy-sc-search-row-title" });
      titleEl.innerHTML = highlightMatch(item.title, input.value.trim());
      body.appendChild(titleEl);
      body.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-row-sub" }, item.subtitle));
      row.appendChild(body);
      // External link icon
      if (item.url.startsWith("http")) {
        const extIcon = FMHY.Dom.el("span", { class: "fmhy-sc-search-row-ext" });
        FMHY.Icon.inject(extIcon, "external", 12);
        row.appendChild(extIcon);
      }
      row.addEventListener("mousedown", (e) => {
        e.preventDefault(); // prevent input blur
        navigate(item);
      });
      row.addEventListener("mouseenter", () => {
        activeIdx = idx;
        updateActive();
      });
      dropdown.appendChild(row);
    });

    positionDropdown(input);
    document.body.appendChild(dropdown);
  }

  /**
   * Highlight the matched portion of text.
   */
  function highlightMatch(text, query) {
    if (!query) return escapeHtml(text);
    const ql = query.toLowerCase();
    const tl = text.toLowerCase();
    const idx = tl.indexOf(ql);
    if (idx === -1) return escapeHtml(text);
    return escapeHtml(text.substring(0, idx))
      + '<mark class="fmhy-sc-search-highlight">' + escapeHtml(text.substring(idx, idx + ql.length)) + '</mark>'
      + escapeHtml(text.substring(idx + ql.length));
  }

  function escapeHtml(s) {
    return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function positionDropdown(input) {
    if (!dropdown || !input) return;
    const r = input.getBoundingClientRect();
    dropdown.style.left = r.left + window.scrollX + "px";
    dropdown.style.top = r.bottom + window.scrollY + 4 + "px";
    dropdown.style.width = Math.max(r.width, 320) + "px";
  }

  function closeDropdown() {
    if (dropdown) { dropdown.remove(); dropdown = null; }
    currentResults = [];
  }

  function updateActive() {
    if (!dropdown) return;
    const rows = dropdown.querySelectorAll(".fmhy-sc-search-row");
    rows.forEach((r, i) => r.classList.toggle("active", i === activeIdx));
    const active = rows[activeIdx];
    if (active) active.scrollIntoView({ block: "nearest" });
  }

  function onKeydown(e, input) {
    if (!dropdown || currentResults.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      activeIdx = (activeIdx + 1) % currentResults.length;
      updateActive();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      activeIdx = (activeIdx - 1 + currentResults.length) % currentResults.length;
      updateActive();
    } else if (e.key === "Enter" && currentResults[activeIdx]) {
      e.preventDefault();
      e.stopPropagation();
      navigate(currentResults[activeIdx]);
    } else if (e.key === "Escape") {
      closeDropdown();
    }
  }

  function navigate(item) {
    if (item.url.startsWith("#")) {
      const el = document.getElementById(item.url.slice(1));
      if (el) el.scrollIntoView({ behavior: "smooth" });
    } else {
      window.open(item.url, "_blank", "noopener");
    }
    closeDropdown();
    // Record in history
    FMHY.Storage.pushHistory({
      url: item.url,
      title: item.title,
      category: item.category || FMHY.Dom.getCurrentCategory(),
      visitedAt: Date.now()
    });
  }

  function showToast(msg, type = "info") {
    if (FMHY.Sidebar && FMHY.Sidebar.showToast) FMHY.Sidebar.showToast(msg, type);
  }

  global.FMHY.registerFeature(NAME, {
    init() {
      if (initialized) return;
      initialized = true;
      const wire = () => findSearchInputs().forEach(attach);
      wire();
      // Re-wire when VitePress swaps content
      FMHY.onPageChange(() => {
        closeDropdown();
        closeAdvanced();
        setTimeout(wire, 500);
      });
      // Also try again after a delay (VitePress loads search lazily)
      setTimeout(wire, 2000);
    },
    onMessage() { return false; },
    refresh: refreshCache,
    isEnabled,
    openAdvanced: () => {
      const toggle = document.querySelector(".fmhy-sc-search-toggle");
      if (toggle) openAdvanced(toggle);
    }
  });

})(typeof globalThis !== "undefined" ? globalThis : (typeof self !== "undefined" ? self : this));
