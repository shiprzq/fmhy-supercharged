/**
 * FMHY Supercharged — Custom Search Overlay
 * =====================================================================
 *
 * Completely replaces VitePress's default search with a beautiful custom
 * overlay. When the user clicks the search button (or presses the
 * keyboard shortcut), we PREVENT VitePress's modal from opening and
 * show our own instead.
 *
 * Features:
 *   - Ghost text autocomplete that fades in (type "chat" → see "gpt" faded)
 *   - Click any suggestion to open it instantly
 *   - Reload button on each suggestion for alternatives
 *   - Advanced search filters (category, type, trust, match mode, sort)
 *   - Keyboard navigation (↑↓ Enter Esc Tab)
 *   - Searches: page links + bookmarks + history + headings
 *   - Beautiful animations: backdrop blur, slide-in, stagger
 *   - Mobile: full-screen with bottom-sheet filters
 *
 * @module FMHY.searchEnhancer
 */
(function (global) {
  "use strict";
  global.FMHY = global.FMHY || {};

  const NAME = "searchEnhancer";
  let initialized = false;
  let overlay = null;
  let input = null;
  let resultsBox = null;
  let advancedPanel = null;
  let activeIdx = 0;
  let currentResults = [];
  let currentQuery = "";
  let navToggleBtn = null;

  /** All searchable items. */
  let allItems = [];

  /** Advanced search state. */
  const advanced = {
    enabled: false,
    searchIn: "all",      // all | page | bookmarks | history
    category: "",
    trust: "all",         // all | safe | paid | account | unknown
    sortBy: "relevance",  // relevance | recent | alpha
    matchType: "partial"  // partial | prefix | exact
  };

  /** Recently searched queries (for quick-repeat). */
  let recentQueries = [];

  /**
   * Initialize: inject nav toggle + intercept VitePress search.
   */
  function init() {
    if (initialized) return;
    initialized = true;

    // Inject toggle into nav bar
    injectNavToggle();

    // Intercept VitePress search button clicks
    interceptVitePressSearch();

    // Also intercept Ctrl+K
    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        e.stopPropagation();
        openOverlay();
      }
    });

    // Load recent queries
    FMHY.Storage.get("recentQueries").then((q) => { recentQueries = q || []; });

    FMHY.onPageChange(() => {
      setTimeout(() => { injectNavToggle(); interceptVitePressSearch(); refreshCache(); }, 500);
    });

    refreshCache();
  }

  /**
   * Inject the toggle icon into VitePress's nav bar.
   */
  function injectNavToggle() {
    const searchBtn = document.querySelector(".VPNavBarSearch, .DocSearch-Button");
    if (!searchBtn) return;
    const navBar = searchBtn.closest(".VPNavBar") || searchBtn.parentElement;
    if (!navBar) return;
    if (navBar.querySelector(".fmhy-sc-search-toggle")) return;

    navToggleBtn = FMHY.Dom.el("button", {
      class: "fmhy-sc-search-toggle",
      "aria-label": "Open FMHY Supercharged search",
      title: "FMHY Supercharged search (Ctrl+K)",
      type: "button"
    });
    navToggleBtn.appendChild(FMHY.Icon.render("search", 16));
    navToggleBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openOverlay();
    });

    if (searchBtn.parentElement === navBar) {
      searchBtn.insertAdjacentElement("afterend", navToggleBtn);
    } else {
      navBar.appendChild(navToggleBtn);
    }
  }

  /**
   * Intercept VitePress's search button to open our overlay instead.
   */
  function interceptVitePressSearch() {
    const searchBtn = document.querySelector(".DocSearch-Button");
    if (!searchBtn || searchBtn.dataset.fmhyIntercepted) return;
    searchBtn.dataset.fmhyIntercepted = "1";

    searchBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openOverlay();
    }, true); // capture phase — runs before VitePress's handler
  }

  /**
   * Refresh the searchable items cache.
   */
  async function refreshCache() {
    const pageLinks = FMHY.Dom.getResourceLinks().map((l) => ({
      type: "page-link",
      title: l.text,
      subtitle: `Page · ${hostnameOf(l.href)}`,
      url: l.href,
      category: FMHY.Dom.getCurrentCategory(),
      addedAt: 0
    }));

    const headings = [];
    document.querySelectorAll("main h2, main h3, .vp-doc h2, .vp-doc h3, article h2, article h3").forEach((h) => {
      if (!h.id) h.id = "fmhy-heading-" + Math.random().toString(36).slice(2, 8);
      headings.push({
        type: "heading",
        title: h.textContent.trim(),
        subtitle: "Section on this page",
        url: "#" + h.id,
        category: FMHY.Dom.getCurrentCategory(),
        addedAt: 0
      });
    });

    const [bms, hist] = await Promise.all([
      FMHY.Storage.getBookmarks(),
      FMHY.Storage.getHistory()
    ]);
    const bookmarks = bms.map((b) => ({
      type: "bookmark", title: b.title,
      subtitle: `Bookmark · ${b.category || "uncategorized"}`,
      url: b.url, category: b.category || "", addedAt: b.addedAt || 0
    }));
    const history = hist.map((h) => ({
      type: "history", title: h.title || h.url,
      subtitle: `Recent · ${FMHY.Dom.timeAgo(h.visitedAt)}`,
      url: h.url, category: h.category || "", addedAt: h.visitedAt || 0
    }));

    const seen = new Set();
    allItems = [];
    [...bookmarks, ...history, ...pageLinks, ...headings].forEach((item) => {
      const key = item.url || item.title.toLowerCase();
      if (!seen.has(key)) { seen.add(key); allItems.push(item); }
    });
  }

  function hostnameOf(url) {
    try { return new URL(url).hostname; } catch (e) { return ""; }
  }

  /**
   * Open the custom search overlay.
   */
  function openOverlay() {
    if (overlay) { closeOverlay(); return; }

    // Prevent body scroll
    document.body.style.overflow = "hidden";

    overlay = FMHY.Dom.el("div", {
      class: "fmhy-sc-search-overlay",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": "Search"
    });

    // Click backdrop to close
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeOverlay();
    });

    // Search box
    const box = FMHY.Dom.el("div", { class: "fmhy-sc-search-box" });

    // Input row
    const inputRow = FMHY.Dom.el("div", { class: "fmhy-sc-search-input-row" });
    const searchIcon = FMHY.Dom.el("span", { class: "fmhy-sc-search-input-icon" });
    FMHY.Icon.inject(searchIcon, "search", 20);
    inputRow.appendChild(searchIcon);

    input = FMHY.Dom.el("input", {
      type: "text",
      class: "fmhy-sc-search-input",
      placeholder: "Search resources, bookmarks, history...",
      autocomplete: "off",
      spellcheck: "false"
    });
    inputRow.appendChild(input);

    // Advanced toggle button
    const advBtn = FMHY.Dom.el("button", {
      class: "fmhy-sc-search-adv-btn" + (advanced.enabled ? " active" : ""),
      title: "Advanced search filters",
      "aria-label": "Advanced filters",
      type: "button"
    });
    FMHY.Icon.inject(advBtn, "settings", 16);
    advBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleAdvancedPanel();
    });
    inputRow.appendChild(advBtn);

    // Close button
    const closeBtn = FMHY.Dom.el("button", {
      class: "fmhy-sc-search-close-btn",
      "aria-label": "Close",
      title: "Close (Esc)"
    });
    closeBtn.appendChild(FMHY.Icon.render("close", 18));
    closeBtn.addEventListener("click", closeOverlay);
    inputRow.appendChild(closeBtn);

    box.appendChild(inputRow);

    // Advanced panel (hidden by default)
    advancedPanel = buildAdvancedPanel();
    advancedPanel.style.display = advanced.enabled ? "block" : "none";
    box.appendChild(advancedPanel);

    // Results area
    resultsBox = FMHY.Dom.el("div", { class: "fmhy-sc-search-results" });
    box.appendChild(resultsBox);

    // Footer with hints
    const footer = FMHY.Dom.el("div", { class: "fmhy-sc-search-footer" });
    footer.appendChild(FMHY.Dom.el("span", {}, "↑↓ navigate · Enter open · Tab reload suggestion · Esc close"));
    box.appendChild(footer);

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    // Animate in
    requestAnimationFrame(() => overlay.classList.add("visible"));
    setTimeout(() => input.focus(), 100);

    // Show recent queries initially
    if (recentQueries.length > 0) {
      showRecentQueries();
    } else {
      showHint();
    }

    // Wire input events
    input.addEventListener("input", FMHY.Dom.debounce(onInput, 100));
    input.addEventListener("keydown", onKeydown);

    // Esc to close (global)
    document.addEventListener("keydown", onGlobalKeydown, true);
  }

  /**
   * Close the overlay.
   */
  function closeOverlay() {
    if (!overlay) return;
    overlay.classList.remove("visible");
    setTimeout(() => {
      if (overlay) { overlay.remove(); overlay = null; }
      input = null;
      resultsBox = null;
      advancedPanel = null;
      currentResults = [];
      currentQuery = "";
    }, 200);
    document.body.style.overflow = "";
    document.removeEventListener("keydown", onGlobalKeydown, true);
  }

  function onGlobalKeydown(e) {
    if (e.key === "Escape" && overlay) {
      e.preventDefault();
      e.stopPropagation();
      closeOverlay();
    }
  }

  /**
   * Build the advanced search panel.
   */
  function buildAdvancedPanel() {
    const panel = FMHY.Dom.el("div", { class: "fmhy-sc-search-adv-panel" });

    // Search in
    const searchInRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    searchInRow.appendChild(FMHY.Dom.el("label", {}, "Search in"));
    const searchInSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "all", l: "All sources" },
      { v: "page", l: "Current page only" },
      { v: "bookmarks", l: "Bookmarks only" },
      { v: "history", l: "Recently viewed only" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.searchIn === o.v) opt.selected = true;
      searchInSelect.appendChild(opt);
    });
    searchInSelect.addEventListener("change", (e) => {
      advanced.searchIn = e.target.value;
      if (input && input.value) onInput();
    });
    searchInRow.appendChild(searchInSelect);
    panel.appendChild(searchInRow);

    // Match type
    const matchRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    matchRow.appendChild(FMHY.Dom.el("label", {}, "Match type"));
    const matchSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "partial", l: "Partial (contains)" },
      { v: "prefix", l: "Prefix (starts with)" },
      { v: "exact", l: "Exact match" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.matchType === o.v) opt.selected = true;
      matchSelect.appendChild(opt);
    });
    matchSelect.addEventListener("change", (e) => {
      advanced.matchType = e.target.value;
      if (input && input.value) onInput();
    });
    matchRow.appendChild(matchSelect);
    panel.appendChild(matchRow);

    // Trust filter
    const trustRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    trustRow.appendChild(FMHY.Dom.el("label", {}, "Trust level"));
    const trustSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "all", l: "Any trust level" },
      { v: "safe", l: "Trusted (open-source)" },
      { v: "paid", l: "May require payment" },
      { v: "account", l: "May require account" },
      { v: "unknown", l: "Unknown" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.trust === o.v) opt.selected = true;
      trustSelect.appendChild(opt);
    });
    trustSelect.addEventListener("change", (e) => {
      advanced.trust = e.target.value;
      if (input && input.value) onInput();
    });
    trustRow.appendChild(trustSelect);
    panel.appendChild(trustRow);

    // Sort by
    const sortRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    sortRow.appendChild(FMHY.Dom.el("label", {}, "Sort by"));
    const sortSelect = FMHY.Dom.el("select", { class: "fmhy-sc-adv-select" });
    [
      { v: "relevance", l: "Relevance" },
      { v: "recent", l: "Recently added" },
      { v: "alpha", l: "Alphabetical (A-Z)" }
    ].forEach((o) => {
      const opt = FMHY.Dom.el("option", { value: o.v }, o.l);
      if (advanced.sortBy === o.v) opt.selected = true;
      sortSelect.appendChild(opt);
    });
    sortSelect.addEventListener("change", (e) => {
      advanced.sortBy = e.target.value;
      if (input && input.value) onInput();
    });
    sortRow.appendChild(sortSelect);
    panel.appendChild(sortRow);

    // Category filter
    const catRow = FMHY.Dom.el("div", { class: "fmhy-sc-adv-row" });
    catRow.appendChild(FMHY.Dom.el("label", {}, "Category filter"));
    const catInput = FMHY.Dom.el("input", {
      type: "text",
      class: "fmhy-sc-adv-input",
      placeholder: "e.g. ai, storage, torrenting",
      value: advanced.category
    });
    catInput.addEventListener("input", (e) => {
      advanced.category = e.target.value.trim().toLowerCase();
      if (input && input.value) onInput();
    });
    catRow.appendChild(catInput);
    panel.appendChild(catRow);

    return panel;
  }

  function toggleAdvancedPanel() {
    if (!advancedPanel) return;
    advanced.enabled = !advanced.enabled;
    advancedPanel.style.display = advanced.enabled ? "block" : "none";
    const advBtn = overlay.querySelector(".fmhy-sc-search-adv-btn");
    if (advBtn) advBtn.classList.toggle("active", advanced.enabled);
  }

  /**
   * Handle input — show autocomplete results.
   */
  async function onInput() {
    if (!input) return;
    const q = input.value.trim();
    currentQuery = q;

    if (!q) {
      if (recentQueries.length > 0) showRecentQueries();
      else showHint();
      return;
    }

    if (allItems.length === 0) await refreshCache();

    const results = gatherResults(q);
    if (results.length === 0) {
      showNoResults(q);
      return;
    }
    showResults(results);
  }

  /**
   * Gather + filter + sort results.
   */
  function gatherResults(q) {
    const ql = q.toLowerCase();
    let pool = [];

    if (advanced.searchIn === "all" || advanced.searchIn === "page") {
      pool = pool.concat(allItems.filter((i) => i.type === "page-link" || i.type === "heading"));
    }
    if (advanced.searchIn === "all" || advanced.searchIn === "bookmarks") {
      pool = pool.concat(allItems.filter((i) => i.type === "bookmark"));
    }
    if (advanced.searchIn === "all" || advanced.searchIn === "history") {
      pool = pool.concat(allItems.filter((i) => i.type === "history"));
    }

    // Match type filter
    const matches = (text) => {
      if (!text) return false;
      const t = text.toLowerCase();
      if (advanced.matchType === "exact") return t === ql;
      if (advanced.matchType === "prefix") return t.startsWith(ql);
      return t.includes(ql);
    };

    let results = pool.filter((item) => matches(item.title) || matches(item.url));

    // Category filter
    if (advanced.category) {
      results = results.filter((i) => i.category && i.category.toLowerCase().includes(advanced.category));
    }

    // Trust filter
    if (advanced.trust !== "all") {
      results = results.filter((i) => classifyTrust(i.title) === advanced.trust);
    }

    // Score
    results = results.map((item) => {
      const tl = (item.title || "").toLowerCase();
      let score = 0;
      if (tl === ql) score = 100;
      else if (tl.startsWith(ql)) score = 80;
      else if (tl.includes(ql)) score = 60;
      else score = 10;
      return { ...item, score };
    });

    // Sort
    if (advanced.sortBy === "recent") {
      results.sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
    } else if (advanced.sortBy === "alpha") {
      results.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    } else {
      results.sort((a, b) => b.score - a.score);
    }

    return results.slice(0, 8);
  }

  function classifyTrust(text) {
    const t = (text || "").toLowerCase();
    const SAFE = ["open source", "open-source", "github", "gitlab", "self-hosted", "selfhost"];
    const PAID = ["premium", "subscribe", "subscription", "pricing"];
    const ACCOUNT = ["sign up", "register", "log in", "login", "create account"];
    if (SAFE.some((k) => t.includes(k))) return "safe";
    if (PAID.some((k) => t.includes(k))) return "paid";
    if (ACCOUNT.some((k) => t.includes(k))) return "account";
    return "unknown";
  }

  /**
   * Show results with ghost text + reload buttons.
   */
  function showResults(results) {
    if (!resultsBox) return;
    currentResults = results;
    activeIdx = 0;
    resultsBox.innerHTML = "";

    results.forEach((item, idx) => {
      const row = FMHY.Dom.el("div", {
        class: "fmhy-sc-search-result" + (idx === 0 ? " active" : ""),
        "data-idx": idx
      });

      // Type icon
      const iconWrap = FMHY.Dom.el("span", { class: "fmhy-sc-search-result-icon" });
      const iconName = item.type === "bookmark" ? "bookmark"
        : item.type === "history" ? "history"
        : item.type === "heading" ? "list"
        : "link";
      FMHY.Icon.inject(iconWrap, iconName, 16);
      row.appendChild(iconWrap);

      // Body — title with ghost text
      const body = FMHY.Dom.el("div", { class: "fmhy-sc-search-result-body" });
      const titleEl = FMHY.Dom.el("div", { class: "fmhy-sc-search-result-title" });

      const tl = (item.title || "").toLowerCase();
      const ql = currentQuery.toLowerCase();

      if (tl.startsWith(ql)) {
        titleEl.appendChild(document.createTextNode(item.title.substring(0, currentQuery.length)));
        const ghost = FMHY.Dom.el("span", { class: "fmhy-sc-search-ghost" }, item.title.substring(currentQuery.length));
        titleEl.appendChild(ghost);
      } else if (tl.includes(ql)) {
        const idx2 = tl.indexOf(ql);
        titleEl.appendChild(document.createTextNode(item.title.substring(0, idx2)));
        const mark = FMHY.Dom.el("mark", { class: "fmhy-sc-search-highlight" }, item.title.substring(idx2, idx2 + currentQuery.length));
        titleEl.appendChild(mark);
        titleEl.appendChild(document.createTextNode(item.title.substring(idx2 + currentQuery.length)));
      } else {
        titleEl.appendChild(document.createTextNode(item.title));
      }
      body.appendChild(titleEl);
      body.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-result-sub" }, item.subtitle));
      row.appendChild(body);

      // Reload button
      const reloadBtn = FMHY.Dom.el("button", {
        class: "fmhy-sc-search-reload",
        title: "Show different suggestion (Tab)",
        "aria-label": "Show different suggestion",
        type: "button"
      });
      reloadBtn.appendChild(FMHY.Icon.render("sync", 14));
      reloadBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        replaceSuggestion(idx);
      });
      row.appendChild(reloadBtn);

      row.addEventListener("click", () => navigate(item));
      row.addEventListener("mouseenter", () => {
        activeIdx = idx;
        updateActive();
      });

      resultsBox.appendChild(row);
    });

    // Animate ghost text
    requestAnimationFrame(() => {
      resultsBox.querySelectorAll(".fmhy-sc-search-ghost").forEach((g) => g.classList.add("visible"));
    });
  }

  /**
   * Replace a suggestion with a different one.
   */
  function replaceSuggestion(idx) {
    const currentUrls = currentResults.map((r) => r.url);
    const ql = currentQuery.toLowerCase();
    const alternatives = allItems.filter((item) => {
      if (currentUrls.includes(item.url)) return false;
      const tl = (item.title || "").toLowerCase();
      return tl.includes(ql) || tl.startsWith(ql) ||
        tl.split(/[\s\-_/.()]+/).some((w) => w.startsWith(ql));
    });

    if (alternatives.length === 0) {
      if (FMHY.Sidebar && FMHY.Sidebar.showToast) FMHY.Sidebar.showToast("No more suggestions", "info");
      return;
    }

    currentResults[idx] = alternatives[Math.floor(Math.random() * alternatives.length)];
    showResults(currentResults);
  }

  function showNoResults(query) {
    if (!resultsBox) return;
    currentResults = [];
    resultsBox.innerHTML = "";
    const empty = FMHY.Dom.el("div", { class: "fmhy-sc-search-empty" });
    const iconWrap = FMHY.Dom.el("div", { class: "fmhy-sc-search-empty-icon" });
    FMHY.Icon.inject(iconWrap, "search", 32);
    empty.appendChild(iconWrap);
    empty.appendChild(FMHY.Dom.el("div", {}, `No matches for "${query}"`));
    resultsBox.appendChild(empty);
  }

  function showHint() {
    if (!resultsBox) return;
    currentResults = [];
    resultsBox.innerHTML = "";
    const hint = FMHY.Dom.el("div", { class: "fmhy-sc-search-hint" });
    hint.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-hint-icon" }));
    FMHY.Icon.inject(hint.querySelector(".fmhy-sc-search-hint-icon"), "search", 32);
    hint.appendChild(FMHY.Dom.el("div", {}, "Start typing to search"));
    hint.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-hint-sub" }, "Searches page links, bookmarks, history & headings"));
    resultsBox.appendChild(hint);
  }

  function showRecentQueries() {
    if (!resultsBox) return;
    currentResults = [];
    resultsBox.innerHTML = "";
    const header = FMHY.Dom.el("div", { class: "fmhy-sc-search-recent-header" }, "Recent searches");
    resultsBox.appendChild(header);
    recentQueries.slice(0, 5).forEach((q) => {
      const row = FMHY.Dom.el("div", { class: "fmhy-sc-search-result" });
      const iconWrap = FMHY.Dom.el("span", { class: "fmhy-sc-search-result-icon" });
      FMHY.Icon.inject(iconWrap, "history", 16);
      row.appendChild(iconWrap);
      row.appendChild(FMHY.Dom.el("div", { class: "fmhy-sc-search-result-title" }, q));
      row.addEventListener("click", () => {
        if (input) { input.value = q; onInput(); }
      });
      resultsBox.appendChild(row);
    });
  }

  function updateActive() {
    if (!resultsBox) return;
    const rows = resultsBox.querySelectorAll(".fmhy-sc-search-result");
    rows.forEach((r, i) => r.classList.toggle("active", i === activeIdx));
    const active = rows[activeIdx];
    if (active) active.scrollIntoView({ block: "nearest" });
  }

  function onKeydown(e) {
    if (!overlay) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (currentResults.length > 0) {
        activeIdx = (activeIdx + 1) % currentResults.length;
        updateActive();
      }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (currentResults.length > 0) {
        activeIdx = (activeIdx - 1 + currentResults.length) % currentResults.length;
        updateActive();
      }
    } else if (e.key === "Enter" && currentResults[activeIdx]) {
      e.preventDefault();
      navigate(currentResults[activeIdx]);
    } else if (e.key === "Tab" && currentResults[activeIdx]) {
      e.preventDefault();
      replaceSuggestion(activeIdx);
    }
  }

  /**
   * Navigate to a result + record in history.
   */
  function navigate(item) {
    // Record query in recent searches
    if (currentQuery && !recentQueries.includes(currentQuery)) {
      recentQueries.unshift(currentQuery);
      recentQueries = recentQueries.slice(0, 10);
      FMHY.Storage.set("recentQueries", recentQueries);
    }

    if (item.url.startsWith("#")) {
      const el = document.getElementById(item.url.slice(1));
      if (el) el.scrollIntoView({ behavior: "smooth" });
      closeOverlay();
    } else {
      window.open(item.url, "_blank", "noopener");
    }

    FMHY.Storage.pushHistory({
      url: item.url, title: item.title,
      category: item.category || FMHY.Dom.getCurrentCategory(),
      visitedAt: Date.now()
    });
  }

  /**
   * Public API.
   */
  async function isEnabled() {
    return await FMHY.Storage.getSetting("searchEnhancerEnabled");
  }

  async function toggleEnhanced() {
    const enabled = await isEnabled();
    await FMHY.Storage.setSetting("searchEnhancerEnabled", !enabled);
    if (FMHY.getFeature("sidebar") && FMHY.getFeature("sidebar").refresh) {
      FMHY.getFeature("sidebar").refresh();
    }
    if (!enabled) openOverlay();
  }

  global.FMHY.registerFeature(NAME, {
    init,
    onMessage() { return false; },
    refresh: refreshCache,
    isEnabled,
    toggleEnhanced,
    openAdvanced: openOverlay,
    openOverlay
  });

})(typeof globalThis !== "undefined" ? globalThis : (typeof self !== "undefined" ? self : this));
