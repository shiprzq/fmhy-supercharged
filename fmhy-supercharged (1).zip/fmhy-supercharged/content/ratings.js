/**
 * Feature #27 — Personal Ratings & Reviews Log
 *
 * 1–5 star rating + optional short review on any resource.
 * Adds a star widget next to each resource link.
 */
(function (global) {
  "use strict";
  global.FMHY = global.FMHY || {};

  const NAME = "ratings";
  let initialized = false;

  async function applyRatings() {
    const ratings = await FMHY.Storage.getRatings();
    FMHY.Dom.getResourceLinks().forEach(({ element, href }) => {
      let widget = element.querySelector(".fmhy-ratingwidget");
      if (widget) {
        updateStars(widget, ratings[href]);
        return;
      }
      widget = FMHY.Dom.el("span", { class: "fmhy-ratingwidget", "data-url": href });
      for (let i = 1; i <= 5; i++) {
        const star = FMHY.Dom.el("span", {
          class: "fmhy-star",
          "data-star": i,
          title: `Rate ${i} star${i > 1 ? "s" : ""}`,
          role: "button",
          tabindex: "0"
        }, "☆");
        star.addEventListener("click", (e) => {
          e.preventDefault(); e.stopPropagation();
          onRate(href, i, widget);
        });
        star.addEventListener("mouseenter", () => previewStars(widget, i));
        star.addEventListener("mouseleave", () => updateStars(widget, ratings[href]));
        widget.appendChild(star);
      }
      element.appendChild(widget);
      updateStars(widget, ratings[href]);
    });
  }

  function previewStars(widget, n) {
    widget.querySelectorAll(".fmhy-star").forEach((s, i) => {
      s.textContent = i < n ? "★" : "☆";
      s.classList.toggle("filled", i < n);
    });
  }

  function updateStars(widget, rating) {
    const n = rating ? rating.stars : 0;
    widget.querySelectorAll(".fmhy-star").forEach((s, i) => {
      s.textContent = i < n ? "★" : "☆";
      s.classList.toggle("filled", i < n);
    });
    widget.title = rating ? `You rated ${n}/5${rating.review ? " — " + rating.review : ""}` : "Rate this resource";
  }

  async function onRate(url, n, widget) {
    const existing = await FMHY.Storage.getRating(url);
    if (existing && existing.stars === n) {
      // Clicking same star → remove rating
      await FMHY.Storage.removeRating(url);
    } else {
      // If rating exists, just update stars; otherwise prompt for review
      let review = existing ? existing.review : "";
      if (!existing) {
        review = prompt("Optional short review:", "") || "";
      }
      await FMHY.Storage.setRating(url, n, review);
    }
    await applyRatings();
  }

  global.FMHY.registerFeature(NAME, {
    init() {
      if (initialized) return;
      initialized = true;
      applyRatings();
      FMHY.onPageChange(() => applyRatings());
    },
    refresh() { return applyRatings(); },
    onMessage(msg) {
      if (msg.type === "openRateEditor" && msg.url) {
        // Find the widget on the page and trigger it
        try {
          const widget = document.querySelector(`.fmhy-ratingwidget[data-url="${CSS.escape(msg.url)}"]`);
          if (widget) {
            const star = widget.querySelector('.fmhy-star[data-star="5"]');
            if (star) star.click();
            return true;
          }
        } catch (e) {}
        // Fallback: direct prompt
        const n = parseInt(prompt("Rate 1-5:", "5"), 10);
        if (n >= 1 && n <= 5) {
          const review = prompt("Optional review:", "") || "";
          FMHY.Storage.setRating(msg.url, n, review).then(() => applyRatings());
        }
        return true;
      }
      return false;
    }
  });
})(typeof globalThis !== "undefined" ? globalThis : (typeof self !== "undefined" ? self : this));
