/**
 * Feature #26 — Resource Comparison Matrix
 *
 * Multi-select resources (checkboxes) → "Compare" button → opens a modal
 * with a side-by-side table.
 */
(function (global) {
  "use strict";
  global.FMHY = global.FMHY || {};

  const NAME = "compareMatrix";
  let initialized = false;
  const selected = new Map(); // url → { element, text }

  function addCheckboxes() {
    FMHY.Dom.getResourceLinks().forEach(({ element, href, text }) => {
      if (element.dataset.fmhyCompareCb) return;
      element.dataset.fmhyCompareCb = "1";
      const cb = FMHY.Dom.el("input", {
        type: "checkbox",
        class: "fmhy-compare-cb",
        title: "Add to comparison"
      });
      cb.addEventListener("change", () => {
        if (cb.checked) {
          selected.set(href, { element, text });
          if (selected.size === 1) showCompareButton();
        } else {
          selected.delete(href);
          if (selected.size === 0) hideCompareButton();
        }
      });
      element.appendChild(cb);
    });
  }

  let compareBtn = null;
  function showCompareButton() {
    if (compareBtn) return;
    compareBtn = FMHY.Dom.el("button", { class: "fmhy-compare-fab" }, "⚖ Compare (0)");
    compareBtn.addEventListener("click", openModal);
    document.body.appendChild(compareBtn);
    updateButton();
  }
  function hideCompareButton() {
    if (compareBtn) { compareBtn.remove(); compareBtn = null; }
  }
  function updateButton() {
    if (compareBtn) compareBtn.textContent = `⚖ Compare (${selected.size})`;
  }

  async function openModal() {
    const modal = FMHY.Dom.el("div", { class: "fmhy-modal-overlay" });
    const box = FMHY.Dom.el("div", { class: "fmhy-modal fmhy-modal-wide" });
    box.appendChild(FMHY.Dom.el("h3", {}, "⚖ Resource Comparison"));

    const [notes, ratings, health] = await Promise.all([
      FMHY.Storage.getNotes(),
      FMHY.Storage.getRatings(),
      FMHY.Storage.getAllHealth()
    ]);

    const cols = ["Resource", "Host", "Trust", "Health", "Your rating", "Your note"];
    const table = FMHY.Dom.el("table", { class: "fmhy-compare-table" });
    const thead = FMHY.Dom.el("thead");
    const tr = FMHY.Dom.el("tr");
    cols.forEach((c) => tr.appendChild(FMHY.Dom.el("th", {}, c)));
    thead.appendChild(tr);
    table.appendChild(thead);

    const tbody = FMHY.Dom.el("tbody");
    selected.forEach(({ text }, url) => {
      const row = FMHY.Dom.el("tr");
      row.appendChild(FMHY.Dom.el("td", {}, text));
      let host = "";
      try { host = new URL(url).hostname; } catch (e) {}
      row.appendChild(FMHY.Dom.el("td", {}, host));
      const trust = FMHY.Dom.el("td", {}, "⚪");
      row.appendChild(trust);
      const hRec = health[url];
      row.appendChild(FMHY.Dom.el("td", {}, hRec ? (hRec.status === "alive" ? "✓ alive" : hRec.status === "dead" ? "✗ dead" : "? unknown") : "—"));
      const rRec = ratings[url];
      row.appendChild(FMHY.Dom.el("td", {}, rRec ? "⭐".repeat(rRec.stars) : "—"));
      const nRec = notes[url];
      row.appendChild(FMHY.Dom.el("td", {}, nRec ? nRec.text.slice(0, 60) + (nRec.text.length > 60 ? "…" : "") : "—"));
      tbody.appendChild(row);
    });
    table.appendChild(tbody);
    box.appendChild(table);

    const btns = FMHY.Dom.el("div", { class: "fmhy-modal-btns" });
    const exportBtn = FMHY.Dom.el("button", { class: "fmhy-btn" }, "Export as Markdown");
    exportBtn.addEventListener("click", () => exportMarkdown());
    const close = FMHY.Dom.el("button", { class: "fmhy-btn fmhy-btn-primary" }, "Close");
    close.addEventListener("click", () => modal.remove());
    btns.appendChild(exportBtn);
    btns.appendChild(close);
    box.appendChild(btns);

    modal.appendChild(box);
    modal.addEventListener("click", (e) => { if (e.target === modal) modal.remove(); });
    document.body.appendChild(modal);
  }

  function exportMarkdown() {
    const rows = [];
    selected.forEach(({ text }, url) => {
      rows.push(`| ${text} | ${url} |`);
    });
    const md = `| Resource | URL |\n|---|---|\n${rows.join("\n")}`;
    FMHY.Dom.copyToClipboard(md).then((ok) => {
      alert(ok ? "Comparison table copied to clipboard as Markdown!" : "Copy failed — please try again.");
    });
  }

  global.FMHY.registerFeature(NAME, {
    init() {
      if (initialized) return;
      initialized = true;
      addCheckboxes();
      FMHY.onPageChange(() => {
        selected.clear();
        hideCompareButton();
        addCheckboxes();
      });
    },
    onMessage() { return false; }
  });
})(typeof globalThis !== "undefined" ? globalThis : (typeof self !== "undefined" ? self : this));
