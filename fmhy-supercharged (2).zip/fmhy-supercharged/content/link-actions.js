/**
 * FMHY Supercharged — Consolidated Link Action Popover
 * =====================================================================
 *
 * Instead of scattering 5+ tiny badges next to every resource link on
 * fmhy.net (bookmark, note, rating, safety, share, compare, etc.),
 * this module renders a SINGLE compact "✦" button per link.
 *
 * Clicking it opens a beautiful popover with all per-link actions:
 *
 *   ┌─────────────────────────────────────┐
 *   │  ⚡ Quick actions                    │
 *   │  ─────────────────────────────      │
 *   │  ★ Bookmark this resource           │
 *   │  📝 Add note                        │
 *   │  ⭐ Rate 1-5                         │
 *   │  📌 Pin to quick toolbar            │
 *   │  🎴 Generate share card             │
 *   │  🗄 View on Wayback Machine         │
 *   │  ⚠ Report this resource             │
 *   │  ─────────────────────────────      │
 *   │  🟢 Trust: Open-source              │
 *   │  ✓ Health: Alive (checked 2h ago)   │
 *   │  🔖 Bookmarked 3 days ago           │
 *   └─────────────────────────────────────┘
 *
 * The popover is positioned smartly: opens below the link if there's
 * room, otherwise opens above. Adjusts horizontally to stay on screen.
 *
 * Accessibility:
 *   - Role: dialog, aria-modal
 *   - Esc closes, Tab cycles within
 *   - Click outside closes
 *   - Hover reveals the ✦ button (touch: always visible)
 *
 * @module FMHY.LinkActions
 */
(function (global) {
  "use strict";
  global.FMHY = global.FMHY || {};

  const NAME = "linkActions";
  let initialized = false;
  let activePopover = null;

  /**
   * Attach the ✦ action button to every resource link on the page.
   * Idempotent — safe to call multiple times.
   */
  function attachActionButtons() {
    const links = FMHY.Dom.getResourceLinks();
    links.forEach(({ element, href, text }) => {
      if (element.dataset.fmhyActionBtn) return;
      element.dataset.fmhyActionBtn = "1";

      const btn = FMHY.Dom.el("button", {
        class: "fmhy-link-action-btn",
        "aria-label": `Quick actions for ${text}`,
        "aria-haspopup": "dialog",
        title: "Quick actions"
      }, "✦");

      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        togglePopover(element, href, text);
      });

      element.appendChild(btn);
    });
  }

  /**
   * Toggle the popover for a specific link.
   * If another popover is open, close it first.
   */
  function togglePopover(anchorEl, url, text) {
    if (activePopover && activePopover._url === url) {
      closePopover();
      return;
    }
    closePopover();
    openPopover(anchorEl, url, text);
  }

  /**
   * Open the popover for a link.
   */
  function openPopover(anchorEl, url, text) {
    activePopover = FMHY.Dom.el("div", {
      class: "fmhy-link-popover",
      role: "dialog",
      "aria-modal": "false",
      "aria-label": `Actions for ${text}`
    });
    activePopover._url = url;
    activePopover._text = text;
    activePopover._anchor = anchorEl;

    // Header
    const header = FMHY.Dom.el("div", { class: "fmhy-link-popover-header" });
    header.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-title" }, "⚡ Quick actions"));
    const closeBtn = FMHY.Dom.el("button", {
      class: "fmhy-link-popover-close",
      "aria-label": "Close"
    }, "✕");
    closeBtn.addEventListener("click", closePopover);
    header.appendChild(closeBtn);
    activePopover.appendChild(header);

    // URL preview (truncated)
    const urlPreview = FMHY.Dom.el("div", { class: "fmhy-link-popover-url" });
    let host = "";
    try { host = new URL(url).hostname; } catch (e) {}
    urlPreview.textContent = host || url;
    activePopover.appendChild(urlPreview);

    // Actions list (async because we need storage data)
    const actionsList = FMHY.Dom.el("div", { class: "fmhy-link-popover-actions" });
    actionsList.appendChild(FMHY.Dom.el("div", { class: "fmhy-link-popover-loading" }, "Loading…"));
    activePopover.appendChild(actionsList);

    // Status section (will be populated async)
    const statusSection = FMHY.Dom.el("div", { class: "fmhy-link-popover-status" });
    activePopover.appendChild(statusSection);

    document.body.appendChild(activePopover);
    positionPopover(anchorEl);
    requestAnimationFrame(() => activePopover.classList.add("fmhy-link-popover-visible"));

    // Populate async
    populateActions(actionsList, url, text);
    populateStatus(statusSection, url);

    // Close on outside click / escape
    setTimeout(() => {
      document.addEventListener("click", onOutsideClick);
      document.addEventListener("keydown", onKeydown);
      window.addEventListener("scroll", closePopover, { once: true });
    }, 0);
  }

  /**
   * Populate the actions list with all per-link actions.
   */
  async function populateActions(container, url, text) {
    container.innerHTML = "";

    const existing = await FMHY.Storage.findBookmarkByUrl(url);
    const pinned = await FMHY.Storage.getPinned();
    const isPinned = pinned.includes(url);

    const actions = [
      {
        icon: existing ? "★" : "☆",
        label: existing ? "Remove bookmark" : "Add bookmark",
        color: existing ? "active" : "",
        action: async () => {
          if (existing) {
            await FMHY.Storage.removeBookmark(existing.id);
            showToast("Bookmark removed", "info");
          } else {
            await FMHY.Storage.addBookmark({
              url, title: text,
              category: FMHY.Dom.getCurrentCategory()
            });
            showToast("Bookmarked!", "success");
          }
          closePopover();
        }
      },
      {
        icon: "📝",
        label: "Add note",
        action: () => {
          closePopover();
          setTimeout(() => openNoteEditor(url), 200);
        }
      },
      {
        icon: "⭐",
        label: "Rate 1-5",
        action: () => openRatingPrompt(url)
      },
      {
        icon: isPinned ? "📌" : "📍",
        label: isPinned ? "Unpin from toolbar" : "Pin to toolbar",
        color: isPinned ? "active" : "",
        action: async () => {
          if (isPinned) {
            await FMHY.Storage.unpin(url);
            showToast("Unpinned", "info");
          } else {
            await FMHY.Storage.pin(url);
            showToast("Pinned to toolbar!", "success");
          }
          closePopover();
        }
      },
      {
        icon: "🎴",
        label: "Generate share card",
        action: () => {
          closePopover();
          setTimeout(() => triggerShareCard(url, text), 200);
        }
      },
      {
        icon: "🗄",
        label: "View on Wayback Machine",
        action: () => {
          window.open(`https://web.archive.org/web/*/${url}`, "_blank", "noopener");
          closePopover();
        }
      },
      {
        icon: "⚖",
        label: "Add to comparison",
        action: () => {
          // Trigger the compare checkbox
          const link = FMHY.Dom.getResourceLinks().find((l) => l.href === url);
          if (link) {
            const cb = link.element.querySelector(".fmhy-compare-cb");
            if (cb) {
              cb.checked = !cb.checked;
              cb.dispatchEvent(new Event("change"));
              showToast(cb.checked ? "Added to comparison" : "Removed from comparison", "info");
            }
          }
          closePopover();
        }
      },
      {
        icon: "⚠",
        label: "Report this resource",
        color: "danger",
        action: () => {
          closePopover();
          setTimeout(() => openReportDialog(url, text), 200);
        }
      }
    ];

    actions.forEach((a) => {
      const row = FMHY.Dom.el("button", {
        class: "fmhy-link-popover-action" + (a.color ? " " + a.color : ""),
        role: "menuitem"
      });
      row.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-action-icon" }, a.icon));
      row.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-action-label" }, a.label));
      row.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        a.action();
      });
      container.appendChild(row);
    });
  }

  /**
   * Populate the status section with metadata about this link.
   */
  async function populateStatus(container, url) {
    const [health, rating, note, ratings] = await Promise.all([
      FMHY.Storage.getHealth(url),
      FMHY.Storage.getRating(url),
      FMHY.Storage.getNote(url),
      FMHY.Storage.getRatings()
    ]);

    container.innerHTML = "";

    // Trust indicator
    const links = FMHY.Dom.getResourceLinks();
    const link = links.find((l) => l.href === url);
    if (link) {
      const trust = classifyTrust(link.text);
      const trustRow = FMHY.Dom.el("div", { class: "fmhy-link-popover-status-row" });
      trustRow.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-status-label" }, "Trust"));
      trustRow.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-status-value" }, `${trust.label} ${trust.tip}`));
      container.appendChild(trustRow);
    }

    // Health
    if (health) {
      const healthRow = FMHY.Dom.el("div", { class: "fmhy-link-popover-status-row" });
      healthRow.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-status-label" }, "Health"));
      const healthText = health.status === "alive"
        ? `✓ Alive (${health.statusCode || "OK"})`
        : health.status === "dead"
          ? "✗ Appears dead"
          : "? Unknown (CORS-blocked)";
      healthRow.appendChild(FMHY.Dom.el("span", {
        class: "fmhy-link-popover-status-value fmhy-health-" + health.status
      }, healthText));
      container.appendChild(healthRow);
    }

    // Rating
    if (rating) {
      const ratingRow = FMHY.Dom.el("div", { class: "fmhy-link-popover-status-row" });
      ratingRow.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-status-label" }, "Your rating"));
      ratingRow.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-status-value" }, `${"⭐".repeat(rating.stars)}${"☆".repeat(5 - rating.stars)}`));
      container.appendChild(ratingRow);
    }

    // Note preview
    if (note && note.text) {
      const noteRow = FMHY.Dom.el("div", { class: "fmhy-link-popover-status-row" });
      noteRow.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-status-label" }, "Your note"));
      const preview = note.text.slice(0, 60) + (note.text.length > 60 ? "…" : "");
      noteRow.appendChild(FMHY.Dom.el("span", { class: "fmhy-link-popover-status-value" }, preview));
      container.appendChild(noteRow);
    }
  }

  /**
   * Heuristic trust classifier (mirrors safety-badges.js logic).
   */
  function classifyTrust(text) {
    const t = (text || "").toLowerCase();
    const SAFE_KEYWORDS = ["open source", "open-source", "github", "gitlab", "self-hosted", "selfhost", "no ads", "ad-free", "mit license", "apache license", "gpl"];
    const PAID_KEYWORDS = ["premium", "subscribe", "subscription", "pricing", "upgrade"];
    const ACCOUNT_KEYWORDS = ["sign up", "register", "log in", "login", "create account"];
    if (SAFE_KEYWORDS.some((k) => t.includes(k))) return { label: "🟢", tip: "Open-source / trusted" };
    if (PAID_KEYWORDS.some((k) => t.includes(k))) return { label: "💰", tip: "May require payment" };
    if (ACCOUNT_KEYWORDS.some((k) => t.includes(k))) return { label: "🔑", tip: "May require account" };
    return { label: "⚪", tip: "No safety info" };
  }

  /**
   * Position the popover relative to the anchor element.
   * Smart positioning: prefers below, falls back to above; clamps horizontally.
   */
  function positionPopover(anchorEl) {
    if (!activePopover || !anchorEl) return;
    const r = anchorEl.getBoundingClientRect();
    const popW = 340;
    const popH = activePopover.offsetHeight || 400;
    const scrollY = window.scrollY;
    const scrollX = window.scrollX;
    const viewportH = window.innerHeight;
    const viewportW = window.innerWidth;

    // Vertical: prefer below; if no room, open above
    let top;
    const spaceBelow = viewportH - r.bottom;
    if (spaceBelow > popH + 20) {
      top = r.bottom + scrollY + 6;
      activePopover.classList.remove("fmhy-link-popover-above");
    } else {
      top = r.top + scrollY - popH - 6;
      activePopover.classList.add("fmhy-link-popover-above");
    }

    // Horizontal: center on anchor, clamp to viewport
    let left = r.left + scrollX + (r.width / 2) - (popW / 2);
    if (left < 10) left = 10;
    if (left + popW > viewportW - 10) left = viewportW - popW - 10;

    // On mobile, full width
    if (viewportW < 640) {
      left = 10;
      activePopover.style.width = "calc(100vw - 20px)";
    } else {
      activePopover.style.width = popW + "px";
    }

    activePopover.style.left = left + "px";
    activePopover.style.top = top + "px";
  }

  /**
   * Close the active popover.
   */
  function closePopover() {
    if (!activePopover) return;
    activePopover.classList.remove("fmhy-link-popover-visible");
    const toRemove = activePopover;
    setTimeout(() => toRemove.remove(), 200);
    activePopover = null;
    document.removeEventListener("click", onOutsideClick);
    document.removeEventListener("keydown", onKeydown);
  }

  function onOutsideClick(e) {
    if (activePopover && !activePopover.contains(e.target) && !e.target.classList.contains("fmhy-link-action-btn")) {
      closePopover();
    }
  }

  function onKeydown(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      closePopover();
    }
  }

  // ---------- Helper: trigger other features ----------

  function openNoteEditor(url) {
    const notes = FMHY.getFeature("notes");
    if (notes && notes.onMessage) {
      notes.onMessage({ type: "openNoteEditor", url });
    }
  }

  function openRatingPrompt(url) {
    const ratings = FMHY.getFeature("ratings");
    if (ratings && ratings.onMessage) {
      ratings.onMessage({ type: "openRateEditor", url });
    } else {
      const n = parseInt(prompt("Rate 1-5:", "5"), 10);
      if (n >= 1 && n <= 5) {
        const review = prompt("Optional review:", "") || "";
        FMHY.Storage.setRating(url, n, review).then(() => {
          showToast("Rating saved!", "success");
        });
      }
    }
  }

  function triggerShareCard(url, text) {
    const sc = FMHY.getFeature("shareCards");
    if (sc && sc.onMessage) {
      sc.onMessage({ type: "generateShareCard", url, text });
    }
  }

  function openReportDialog(url, text) {
    const sb = FMHY.getFeature("safetyBadges");
    if (sb && sb.onMessage) {
      sb.onMessage({ type: "reportLink", url, text });
    }
  }

  function showToast(msg, type = "info") {
    if (FMHY.Sidebar && FMHY.Sidebar.showToast) {
      FMHY.Sidebar.showToast(msg, type);
    } else {
      // Fallback
      const t = FMHY.Dom.el("div", { class: "fmhy-toast fmhy-toast-" + type }, msg);
      document.body.appendChild(t);
      setTimeout(() => t.remove(), 2400);
    }
  }

  // ---------- Feature registration ----------

  global.FMHY.registerFeature(NAME, {
    init() {
      if (initialized) return;
      initialized = true;
      attachActionButtons();
      FMHY.onPageChange(() => {
        closePopover();
        setTimeout(attachActionButtons, 100);
      });
    },
    onMessage() { return false; },
    refresh: attachActionButtons,
    close: closePopover
  });

})(typeof globalThis !== "undefined" ? globalThis : (typeof self !== "undefined" ? self : this));
