/**
 * FMHY Supercharged — Unified Sidebar
 * =====================================================================
 *
 * A single, beautiful slide-in sidebar that consolidates ALL features
 * into one clean UI. No more scattered floating buttons across the page.
 *
 * Architecture
 * ------------
 * Every feature module registers itself with the sidebar via
 * `FMHY.Sidebar.register(config)`. The sidebar then renders a button
 * in the appropriate section. When clicked, the feature's `action()`
 * callback fires.
 *
 * Sections
 * --------
 *   - "quick"     : Command palette, radial menu, sync, bookmark page
 *   - "browse"    : Filters, mini-TOC, related sidebar, pinned toolbar
 *   - "saved"     : Recent bookmarks, history, ratings, notes overview
 *   - "tools"     : Density, theme, reading mode, watch, export, compare,
 *                   highlight rules, share cards help
 *
 * Animations
 * ----------
 *   - Backdrop fade-in (200ms ease)
 *   - Sidebar slide-in from right with spring easing (350ms)
 *   - Section tab indicators slide between active tabs
 *   - Row items stagger in on section change (50ms delay each)
 *   - Edge-swipe gesture support (touch devices)
 *
 * Accessibility
 * -------------
 *   - Focus trap when open (Tab cycles within sidebar)
 *   - Esc to close
 *   - ARIA roles: dialog, modal, tablist, tab, tabpanel
 *   - Keyboard arrow navigation between tabs
 *   - Screen reader announcements
 *
 * @module FMHY.Sidebar
 */
(function (global) {
  "use strict";
  global.FMHY = global.FMHY || {};

  /** Unique feature identifier for the sidebar module. */
  const NAME = "sidebar";

  /** Registry of all sidebar items, keyed by section then by item id. */
  const registry = {
    quick: [],
    browse: [],
    saved: [],
    tools: []
  };

  /** Whether the sidebar has been initialized. */
  let initialized = false;

  /** Whether the sidebar is currently open. */
  let isOpen = false;

  /** Currently active section tab. */
  let activeSection = "quick";

  /** DOM references (populated on first open). */
  let host = null;        // The host button (floating on the right edge)
  let backdrop = null;    // The blurred backdrop behind the sidebar
  let panel = null;       // The sidebar panel itself
  let sectionTabs = null; // The tab bar
  let sectionContent = null; // The content area where items render

  /** Tab configuration with metadata. */
  const SECTIONS = [
    { id: "quick",  label: "Quick",  icon: "⚡", description: "Fast actions" },
    { id: "browse", label: "Browse", icon: "🧭", description: "Filter & navigate" },
    { id: "saved",  label: "Saved",  icon: "🔖", description: "Your bookmarks & history" },
    { id: "tools",  label: "Tools",  icon: "🛠️", description: "Settings & power tools" }
  ];

  /** Track previously focused element to restore on close (a11y). */
  let previouslyFocused = null;

  /** Edge swipe detection state. */
  const swipeState = {
    active: false,
    startX: 0,
    startY: 0,
    currentX: 0,
    startTime: 0
  };

  /** Minimum swipe distance (px) to register as open gesture. */
  const SWIPE_THRESHOLD = 60;

  /** Maximum time (ms) for a swipe to be considered valid. */
  const SWIPE_TIMEOUT = 600;

  /**
   * Register a feature with the sidebar.
   *
   * @param {Object} config - Registration config
   * @param {string} config.id - Unique identifier (e.g. "export-data")
   * @param {string} config.section - One of: quick, browse, saved, tools
   * @param {string} config.label - Display label
   * @param {string} config.icon - Emoji or single character icon
   * @param {string} [config.description] - Optional sub-text
   * @param {number} [config.order=100] - Sort order within section (lower = higher)
   * @param {Function} config.action - Callback when item is clicked
   * @param {Function} [config.isActive] - Optional predicate returning boolean
   *   (when true, item shows as "active" with primary color)
   * @param {string} [config.badge] - Optional badge text (e.g. count)
   * @returns {boolean} true if registered successfully
   */
  function register(config) {
    if (!config || !config.id || !config.section || !config.action) {
      console.warn("[FMHY SC Sidebar] Invalid registration:", config);
      return false;
    }
    if (!registry[config.section]) {
      console.warn("[FMHY SC Sidebar] Unknown section:", config.section);
      return false;
    }
    // Dedupe by id
    const existingIdx = registry[config.section].findIndex((i) => i.id === config.id);
    if (existingIdx >= 0) {
      registry[config.section][existingIdx] = config;
    } else {
      registry[config.section].push(config);
    }
    // Re-render if sidebar is currently open
    if (isOpen) renderSection();
    return true;
  }

  /**
   * Update a registered item's properties (e.g. badge count, active state).
   *
   * @param {string} id - The item id
   * @param {Object} updates - Partial config to merge
   */
  function updateItem(id, updates) {
    for (const section of Object.keys(registry)) {
      const idx = registry[section].findIndex((i) => i.id === id);
      if (idx >= 0) {
        registry[section][idx] = { ...registry[section][idx], ...updates };
        if (isOpen) renderSection();
        return;
      }
    }
  }

  /**
   * Build the floating host button on the right edge of the screen.
   * Clicking it opens the sidebar.
   */
  function buildHost() {
    if (host) host.remove();
    host = FMHY.Dom.el("button", {
      class: "fmhy-sidebar-host",
      "aria-label": "Open FMHY Supercharged sidebar",
      "aria-expanded": "false",
      "aria-haspopup": "dialog",
      title: "Open FMHY Supercharged (or swipe from right edge on mobile)"
    });
    const icon = FMHY.Dom.el("span", { class: "fmhy-sidebar-host-icon" }, "⚡");
    const pulse = FMHY.Dom.el("span", { class: "fmhy-sidebar-host-pulse" });
    host.appendChild(icon);
    host.appendChild(pulse);
    host.addEventListener("click", open);
    document.body.appendChild(host);

    // Animate in after a tick so the transition fires
    requestAnimationFrame(() => host.classList.add("fmhy-sidebar-host-visible"));
  }

  /**
   * Build the sidebar overlay + panel structure (called once on first open).
   */
  function buildSidebar() {
    if (panel) return;

    // Backdrop
    backdrop = FMHY.Dom.el("div", {
      class: "fmhy-sidebar-backdrop",
      "aria-hidden": "true"
    });
    backdrop.addEventListener("click", close);

    // Panel
    panel = FMHY.Dom.el("aside", {
      class: "fmhy-sidebar-panel",
      role: "dialog",
      "aria-modal": "true",
      "aria-labelledby": "fmhy-sidebar-title"
    });

    // Header
    const header = FMHY.Dom.el("header", { class: "fmhy-sidebar-header" });
    const brand = FMHY.Dom.el("div", { class: "fmhy-sidebar-brand" });
    const brandIcon = FMHY.Dom.el("div", { class: "fmhy-sidebar-brand-icon" });
    const brandIconImg = FMHY.Dom.el("img", {
      src: chrome.runtime.getURL("assets/icon48.png"),
      alt: "",
      width: "24",
      height: "24"
    });
    brandIcon.appendChild(brandIconImg);
    const brandText = FMHY.Dom.el("div", { class: "fmhy-sidebar-brand-text" });
    brandText.appendChild(FMHY.Dom.el("div", {
      class: "fmhy-sidebar-title",
      id: "fmhy-sidebar-title"
    }, "FMHY Supercharged"));
    brandText.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-subtitle" }, "30 features · 1 sidebar"));
    brand.appendChild(brandIcon);
    brand.appendChild(brandText);
    const closeBtn = FMHY.Dom.el("button", {
      class: "fmhy-sidebar-close",
      "aria-label": "Close sidebar",
      title: "Close (Esc)"
    }, "✕");
    closeBtn.addEventListener("click", close);
    header.appendChild(brand);
    header.appendChild(closeBtn);
    panel.appendChild(header);

    // Tabs
    sectionTabs = FMHY.Dom.el("nav", {
      class: "fmhy-sidebar-tabs",
      role: "tablist",
      "aria-label": "Sidebar sections"
    });
    SECTIONS.forEach((section, idx) => {
      const tab = FMHY.Dom.el("button", {
        class: "fmhy-sidebar-tab" + (section.id === activeSection ? " active" : ""),
        role: "tab",
        "aria-selected": section.id === activeSection ? "true" : "false",
        "aria-controls": `fmhy-sidebar-panel-${section.id}`,
        id: `fmhy-sidebar-tab-${section.id}`,
        "data-section": section.id,
        tabindex: idx === 0 ? "0" : "-1"
      });
      const icon = FMHY.Dom.el("span", { class: "fmhy-sidebar-tab-icon" }, section.icon);
      const label = FMHY.Dom.el("span", { class: "fmhy-sidebar-tab-label" }, section.label);
      tab.appendChild(icon);
      tab.appendChild(label);
      tab.addEventListener("click", () => switchSection(section.id));
      tab.addEventListener("keydown", onTabKeydown);
      sectionTabs.appendChild(tab);
    });
    panel.appendChild(sectionTabs);

    // Content area
    sectionContent = FMHY.Dom.el("div", { class: "fmhy-sidebar-content" });
    panel.appendChild(sectionContent);

    // Footer
    const footer = FMHY.Dom.el("footer", { class: "fmhy-sidebar-footer" });
    const hint = FMHY.Dom.el("span", { class: "fmhy-sidebar-footer-hint" }, "Made with ❤ for fmhy.net");
    footer.appendChild(hint);
    panel.appendChild(footer);

    backdrop.appendChild(panel);
    document.body.appendChild(backdrop);
  }

  /**
   * Render the items for the active section.
   * Items are sorted by `order` (default 100), then by registration time.
   * Each item animates in with a stagger delay.
   */
  function renderSection() {
    if (!sectionContent) return;
    sectionContent.innerHTML = "";

    const sectionId = `fmhy-sidebar-panel-${activeSection}`;
    sectionContent.setAttribute("role", "tabpanel");
    sectionContent.setAttribute("id", sectionId);
    sectionContent.setAttribute("aria-labelledby", `fmhy-sidebar-tab-${activeSection}`);

    const items = (registry[activeSection] || [])
      .slice()
      .sort((a, b) => (a.order || 100) - (b.order || 100));

    if (items.length === 0) {
      const empty = FMHY.Dom.el("div", { class: "fmhy-sidebar-empty" });
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-icon" }, "✨"));
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-text" }, "No items in this section yet."));
      sectionContent.appendChild(empty);
      return;
    }

    items.forEach((item, idx) => {
      const row = buildItemRow(item, idx);
      sectionContent.appendChild(row);
    });
  }

  /**
   * Build a single item row.
   *
   * @param {Object} item - The registration config
   * @param {number} index - For stagger animation delay
   * @returns {HTMLElement} The row element
   */
  function buildItemRow(item, index) {
    const isActive = typeof item.isActive === "function" ? item.isActive() : false;
    const row = FMHY.Dom.el("button", {
      class: "fmhy-sidebar-item" + (isActive ? " active" : ""),
      style: { animationDelay: `${index * 50}ms` },
      "aria-label": item.label + (item.description ? " — " + item.description : "")
    });

    // Icon
    const iconWrap = FMHY.Dom.el("span", { class: "fmhy-sidebar-item-icon" }, item.icon || "•");
    row.appendChild(iconWrap);

    // Body (label + description)
    const body = FMHY.Dom.el("div", { class: "fmhy-sidebar-item-body" });
    body.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-item-label" }, item.label));
    if (item.description) {
      body.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-item-desc" }, item.description));
    }
    row.appendChild(body);

    // Badge (optional)
    if (item.badge) {
      const badge = FMHY.Dom.el("span", { class: "fmhy-sidebar-item-badge" }, String(item.badge));
      row.appendChild(badge);
    }

    // Chevron
    const chevron = FMHY.Dom.el("span", { class: "fmhy-sidebar-item-chevron" }, "›");
    row.appendChild(chevron);

    // Click handler with error boundary
    row.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      // Visual feedback: ripple
      createRipple(row, e);
      try {
        await item.action();
        // Re-render to update active state if predicate changed
        renderSection();
      } catch (err) {
        console.error("[FMHY SC Sidebar] Item action failed:", err);
        showToast("Action failed: " + err.message, "error");
      }
    });

    return row;
  }

  /**
   * Create a material-style ripple effect on click.
   *
   * @param {HTMLElement} element - The element to ripple on
   * @param {Event} event - The click event
   */
  function createRipple(element, event) {
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = (event.clientX || rect.left + rect.width / 2) - rect.left - size / 2;
    const y = (event.clientY || rect.top + rect.height / 2) - rect.top - size / 2;
    const ripple = FMHY.Dom.el("span", {
      class: "fmhy-ripple",
      style: {
        width: size + "px",
        height: size + "px",
        left: x + "px",
        top: y + "px"
      }
    });
    element.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
  }

  /**
   * Open the sidebar. Builds it on first call.
   */
  function open() {
    if (isOpen) return;
    buildSidebar();
    isOpen = true;

    // Save focus for restoration
    previouslyFocused = document.activeElement;

    // Animate in
    requestAnimationFrame(() => {
      backdrop.classList.add("fmhy-sidebar-visible");
      if (host) {
        host.setAttribute("aria-expanded", "true");
        host.classList.add("fmhy-sidebar-host-hidden");
      }
    });

    // Render current section
    renderSection();

    // Focus first focusable element
    setTimeout(() => {
      const firstFocusable = panel.querySelector("button, [tabindex]:not([tabindex='-1'])");
      if (firstFocusable) firstFocusable.focus();
    }, 350);

    // Lock body scroll
    document.body.style.overflow = "hidden";

    // Listen for escape
    document.addEventListener("keydown", onKeyDown, true);
  }

  /**
   * Close the sidebar.
   */
  function close() {
    if (!isOpen) return;
    isOpen = false;

    backdrop.classList.remove("fmhy-sidebar-visible");
    if (host) {
      host.setAttribute("aria-expanded", "false");
      host.classList.remove("fmhy-sidebar-host-hidden");
    }

    // Restore body scroll
    document.body.style.overflow = "";

    // Restore focus
    if (previouslyFocused && typeof previouslyFocused.focus === "function") {
      previouslyFocused.focus();
    }
    previouslyFocused = null;

    document.removeEventListener("keydown", onKeyDown, true);
  }

  /**
   * Toggle the sidebar open/closed.
   */
  function toggle() {
    if (isOpen) close();
    else open();
  }

  /**
   * Switch to a different section.
   *
   * @param {string} sectionId - One of: quick, browse, saved, tools
   */
  function switchSection(sectionId) {
    if (!registry[sectionId]) return;
    if (sectionId === activeSection) return;
    activeSection = sectionId;

    // Update tabs
    sectionTabs.querySelectorAll(".fmhy-sidebar-tab").forEach((tab) => {
      const isActive = tab.dataset.section === sectionId;
      tab.classList.toggle("active", isActive);
      tab.setAttribute("aria-selected", isActive ? "true" : "false");
      tab.setAttribute("tabindex", isActive ? "0" : "-1");
    });

    // Animate content out then in
    sectionContent.classList.add("fmhy-sidebar-content-exiting");
    setTimeout(() => {
      renderSection();
      sectionContent.classList.remove("fmhy-sidebar-content-exiting");
      sectionContent.classList.add("fmhy-sidebar-content-entering");
      setTimeout(() => sectionContent.classList.remove("fmhy-sidebar-content-entering"), 300);
    }, 150);
  }

  /**
   * Keyboard handler for Escape (close) and focus trap.
   */
  function onKeyDown(e) {
    if (!isOpen) return;
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      close();
      return;
    }
    // Focus trap: Tab cycles within sidebar
    if (e.key === "Tab" && panel) {
      const focusable = panel.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  }

  /**
   * Keyboard handler for tab navigation (arrow keys).
   */
  function onTabKeydown(e) {
    const tabs = Array.from(sectionTabs.querySelectorAll(".fmhy-sidebar-tab"));
    const currentIdx = tabs.findIndex((t) => t === document.activeElement);
    if (currentIdx === -1) return;

    let newIdx = currentIdx;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      e.preventDefault();
      newIdx = (currentIdx + 1) % tabs.length;
    } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      e.preventDefault();
      newIdx = (currentIdx - 1 + tabs.length) % tabs.length;
    } else if (e.key === "Home") {
      e.preventDefault();
      newIdx = 0;
    } else if (e.key === "End") {
      e.preventDefault();
      newIdx = tabs.length - 1;
    } else {
      return;
    }

    tabs[newIdx].focus();
    switchSection(tabs[newIdx].dataset.section);
  }

  /**
   * Set up edge-swipe gesture detection for touch devices.
   * Swiping from the right edge of the screen opens the sidebar.
   * Swiping right-to-left on an open sidebar closes it.
   */
  function setupSwipeGesture() {
    // Only enable on touch devices
    if (!("ontouchstart" in window)) return;

    document.addEventListener("touchstart", (e) => {
      // Only track touches that start near the right edge
      const touch = e.touches[0];
      const edgeThreshold = 30; // px from right edge
      if (!isOpen && touch.clientX < window.innerWidth - edgeThreshold) {
        return; // Not an edge swipe attempt
      }
      swipeState.active = true;
      swipeState.startX = touch.clientX;
      swipeState.startY = touch.clientY;
      swipeState.currentX = touch.clientX;
      swipeState.startTime = Date.now();
    }, { passive: true });

    document.addEventListener("touchmove", (e) => {
      if (!swipeState.active) return;
      const touch = e.touches[0];
      swipeState.currentX = touch.clientX;
    }, { passive: true });

    document.addEventListener("touchend", (e) => {
      if (!swipeState.active) return;
      swipeState.active = false;

      const elapsed = Date.now() - swipeState.startTime;
      if (elapsed > SWIPE_TIMEOUT) return;

      const dx = swipeState.currentX - swipeState.startX;
      const dy = Math.abs(e.changedTouches[0].clientY - swipeState.startY);

      // Must be primarily horizontal
      if (dy > 60) return;

      if (!isOpen && dx < -SWIPE_THRESHOLD) {
        // Swipe left from right edge → open
        open();
      } else if (isOpen && dx > SWIPE_THRESHOLD) {
        // Swipe right → close
        close();
      }
    }, { passive: true });
  }

  /**
   * Show a transient toast notification.
   *
   * @param {string} message - Message to display
   * @param {string} [type="info"] - One of: info, success, error
   */
  function showToast(message, type = "info") {
    const toast = FMHY.Dom.el("div", {
      class: `fmhy-toast fmhy-toast-${type}`,
      role: "status",
      "aria-live": "polite"
    }, message);
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("fmhy-toast-visible"));
    setTimeout(() => {
      toast.classList.remove("fmhy-toast-visible");
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // ---------- Public API ----------

  global.FMHY.Sidebar = {
    register,
    updateItem,
    open,
    close,
    toggle,
    switchSection,
    isOpen: () => isOpen,
    showToast
  };

  // ---------- Feature registration ----------

  global.FMHY.registerFeature(NAME, {
    init() {
      if (initialized) return;
      initialized = true;
      buildHost();
      setupSwipeGesture();

      // Register built-in quick actions
      register({
        id: "command-palette",
        section: "quick",
        label: "Command Palette",
        icon: "⚡",
        description: "Search all resources, bookmarks & history",
        order: 1,
        action: () => {
          close();
          setTimeout(() => {
            const cp = FMHY.getFeature("commandPalette");
            if (cp) cp.onMessage({ type: "openCommandPalette" });
          }, 350);
        }
      });

      register({
        id: "radial-menu",
        section: "quick",
        label: "Category Radial",
        icon: "✦",
        description: "Visual jump to any of 15 categories",
        order: 2,
        action: () => {
          close();
          setTimeout(() => {
            const rm = FMHY.getFeature("radialMenu");
            if (rm) rm.onMessage({ type: "openRadialMenu" });
          }, 350);
        }
      });

      register({
        id: "bookmark-page",
        section: "quick",
        label: "Bookmark This Page",
        icon: "★",
        description: "Save the current fmhy.net page",
        order: 3,
        action: async () => {
          const url = window.location.href;
          const title = FMHY.Dom.getPageTitle();
          const category = FMHY.Dom.getCurrentCategory();
          const existing = await FMHY.Storage.findBookmarkByUrl(url);
          if (existing) {
            await FMHY.Storage.removeBookmark(existing.id);
            showToast("Bookmark removed", "info");
          } else {
            await FMHY.Storage.addBookmark({ url, title, category });
            showToast("Bookmark added!", "success");
          }
          // Refresh bookmarks feature
          const bm = FMHY.getFeature("bookmarks");
          if (bm && bm.refreshBookmarkedSet) bm.refreshBookmarkedSet();
        }
      });

      register({
        id: "sync-now",
        section: "quick",
        label: "Sync Now",
        icon: "🔄",
        description: "Push/pull bookmarks via GitHub Gist or WebDAV",
        order: 4,
        action: async () => {
          const cfg = await FMHY.Storage.getSyncConfig();
          if (cfg.provider === "none" || !cfg.token) {
            showToast("Sync not configured — set up in Options", "error");
            return;
          }
          showToast("Syncing…", "info");
          try {
            await chrome.runtime.sendMessage({ type: "syncNow" });
            showToast("Synced successfully!", "success");
          } catch (e) {
            showToast("Sync failed: " + e.message, "error");
          }
        }
      });

      // Tools section items (these control features by toggling them)
      register({
        id: "reading-mode",
        section: "tools",
        label: "Reading Mode",
        icon: "📖",
        description: "Hide everything except current section",
        order: 1,
        isActive: () => document.body.classList.contains("fmhy-reading-mode"),
        action: () => {
          document.body.classList.toggle("fmhy-reading-mode");
          const rm = FMHY.getFeature("readingMode");
          if (rm && rm.toggle) rm.toggle();
        }
      });

      register({
        id: "density-cycle",
        section: "tools",
        label: "Density Mode",
        icon: "📐",
        description: "Cycle: compact → comfortable → spacious",
        order: 2,
        isActive: async () => {
          const d = await FMHY.Storage.getSetting("density");
          return d === "spacious";
        },
        action: async () => {
          const order = ["compact", "comfortable", "spacious"];
          const current = await FMHY.Storage.getSetting("density");
          const idx = order.indexOf(current);
          const next = order[(idx + 1) % order.length];
          await FMHY.Storage.setSetting("density", next);
          document.documentElement.setAttribute("data-fmhy-density", next);
          showToast(`Density: ${next}`, "info");
        }
      });

      register({
        id: "export-data",
        section: "tools",
        label: "Export Data",
        icon: "💾",
        description: "JSON / HTML / Markdown / CSV",
        order: 3,
        action: () => {
          close();
          setTimeout(() => {
            const et = FMHY.getFeature("exportTools");
            if (et && et.openMenu) et.openMenu();
          }, 300);
        }
      });

      register({
        id: "watch-category",
        section: "tools",
        label: "Watch This Category",
        icon: "🔔",
        description: "Get notified when new resources are added here",
        order: 4,
        isActive: async () => {
          const cat = FMHY.Dom.getCurrentCategory();
          const watched = await FMHY.Storage.getWatchedCategories();
          return watched.includes(cat);
        },
        action: async () => {
          const cat = FMHY.Dom.getCurrentCategory();
          const watched = await FMHY.Storage.getWatchedCategories();
          if (watched.includes(cat)) {
            await FMHY.Storage.unwatchCategory(cat);
            showToast(`Stopped watching ${cat}`, "info");
          } else {
            await FMHY.Storage.watchCategory(cat);
            showToast(`Now watching ${cat}!`, "success");
          }
        }
      });

      register({
        id: "related-resources",
        section: "browse",
        label: "Related Resources",
        icon: "🔗",
        description: "Show resources listed multiple times or in same category",
        order: 1,
        action: () => {
          const rs = FMHY.getFeature("relatedSidebar");
          if (rs && rs.toggle) rs.toggle();
        }
      });

      register({
        id: "mini-toc",
        section: "browse",
        label: "Table of Contents",
        icon: "📑",
        description: "Show floating TOC with scroll-spy",
        order: 2,
        isActive: () => {
          const w = document.querySelector(".fmhy-toc-widget");
          return w && w.style.display !== "none";
        },
        action: () => {
          const w = document.querySelector(".fmhy-toc-widget");
          if (w) {
            const isHidden = w.style.display === "none";
            w.style.display = isHidden ? "" : "none";
            showToast(isHidden ? "TOC shown" : "TOC hidden", "info");
          } else {
            showToast("No headings on this page", "info");
          }
        }
      });

      register({
        id: "compare-matrix",
        section: "tools",
        label: "Compare Resources",
        icon: "⚖",
        description: "Multi-select resources and view side-by-side",
        order: 5,
        action: () => {
          const fab = document.querySelector(".fmhy-compare-fab");
          if (fab) {
            showToast("Checkboxes added to each link — select some, then click ⚖ Compare", "info");
          } else {
            showToast("Compare mode is loading…", "info");
          }
        }
      });

      register({
        id: "open-options",
        section: "tools",
        label: "Open Full Options",
        icon: "⚙",
        description: "Sync setup, highlight rules, watched categories, backup",
        order: 99,
        action: () => {
          if (chrome.runtime.openOptionsPage) {
            chrome.runtime.openOptionsPage();
          }
        }
      });

      // Update saved section badges periodically
      refreshSavedBadges();
    },
    onMessage(msg) {
      if (msg.type === "toggleSidebar") {
        toggle();
        return true;
      }
      return false;
    },
    refresh: refreshSavedBadges
  });

  /**
   * Update the "saved" section with live counts (bookmarks, history, etc.).
   * Called on init and on storage changes.
   */
  async function refreshSavedBadges() {
    const [bookmarks, history, ratings, notes] = await Promise.all([
      FMHY.Storage.getBookmarks(),
      FMHY.Storage.getHistory(),
      FMHY.Storage.getRatings(),
      FMHY.Storage.getNotes()
    ]);

    // Update existing registered items or register them if missing
    register({
      id: "view-bookmarks",
      section: "saved",
      label: "View All Bookmarks",
      icon: "🔖",
      description: `${bookmarks.length} bookmarked resource${bookmarks.length === 1 ? "" : "s"}`,
      badge: bookmarks.length > 0 ? String(bookmarks.length) : undefined,
      order: 1,
      action: () => {
        // Open the popup's bookmarks tab — but we can't directly.
        // Instead, show a simple list inline.
        showBookmarksList(bookmarks);
      }
    });

    register({
      id: "view-history",
      section: "saved",
      label: "Recently Viewed",
      icon: "🕑",
      description: `${history.length} recent visit${history.length === 1 ? "" : "s"}`,
      badge: history.length > 0 ? String(history.length) : undefined,
      order: 2,
      action: () => {
        showHistoryList(history);
      }
    });

    register({
      id: "view-ratings",
      section: "saved",
      label: "Your Ratings",
      icon: "⭐",
      description: `${Object.keys(ratings).length} rated resource${Object.keys(ratings).length === 1 ? "" : "s"}`,
      badge: Object.keys(ratings).length > 0 ? String(Object.keys(ratings).length) : undefined,
      order: 3,
      action: () => {
        showRatingsList(ratings);
      }
    });

    register({
      id: "view-notes",
      section: "saved",
      label: "Your Notes",
      icon: "📝",
      description: `${Object.keys(notes).length} note${Object.keys(notes).length === 1 ? "" : "s"}`,
      badge: Object.keys(notes).length > 0 ? String(Object.keys(notes).length) : undefined,
      order: 4,
      action: () => {
        showNotesList(notes);
      }
    });

    if (isOpen && activeSection === "saved") renderSection();
  }

  /**
   * Show bookmarks list inside the sidebar content area.
   */
  function showBookmarksList(bookmarks) {
    if (!sectionContent) return;
    sectionContent.innerHTML = "";

    if (bookmarks.length === 0) {
      const empty = FMHY.Dom.el("div", { class: "fmhy-sidebar-empty" });
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-icon" }, "🔖"));
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-text" }, "No bookmarks yet. Click the ＋ button next to any resource on fmhy.net."));
      sectionContent.appendChild(empty);
      return;
    }

    const backBtn = FMHY.Dom.el("button", { class: "fmhy-sidebar-back-btn" }, "‹ Back");
    backBtn.addEventListener("click", () => renderSection());
    sectionContent.appendChild(backBtn);

    const list = FMHY.Dom.el("div", { class: "fmhy-sidebar-list" });
    bookmarks.slice(0, 50).forEach((bm, idx) => {
      const row = FMHY.Dom.el("a", {
        class: "fmhy-sidebar-list-item",
        href: bm.url,
        target: "_blank",
        rel: "noopener",
        style: { animationDelay: `${idx * 30}ms` }
      });
      let host = "";
      try { host = new URL(bm.url).hostname; } catch (e) {}
      const fav = host ? `https://www.google.com/s2/favicons?sz=32&domain=${host}` : "";
      row.innerHTML = `
        ${fav ? `<img src="${fav}" alt="" width="20" height="20" onerror="this.style.visibility='hidden'">` : "<span>🔖</span>"}
        <div class="fmhy-sidebar-list-body">
          <div class="fmhy-sidebar-list-title"></div>
          <div class="fmhy-sidebar-list-sub">${bm.category || "uncategorized"} · ${host || "unknown"}</div>
        </div>
        <button class="fmhy-sidebar-list-del" title="Delete">✕</button>
      `;
      row.querySelector(".fmhy-sidebar-list-title").textContent = bm.title;
      row.querySelector(".fmhy-sidebar-list-del").addEventListener("click", async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await FMHY.Storage.removeBookmark(bm.id);
        showToast("Bookmark deleted", "info");
        const updated = await FMHY.Storage.getBookmarks();
        showBookmarksList(updated);
        refreshSavedBadges();
      });
      list.appendChild(row);
    });
    sectionContent.appendChild(list);
  }

  /**
   * Show recently viewed history list.
   */
  function showHistoryList(history) {
    if (!sectionContent) return;
    sectionContent.innerHTML = "";

    if (history.length === 0) {
      const empty = FMHY.Dom.el("div", { class: "fmhy-sidebar-empty" });
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-icon" }, "🕑"));
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-text" }, "No recently viewed resources yet."));
      sectionContent.appendChild(empty);
      return;
    }

    const backBtn = FMHY.Dom.el("button", { class: "fmhy-sidebar-back-btn" }, "‹ Back");
    backBtn.addEventListener("click", () => renderSection());
    sectionContent.appendChild(backBtn);

    const list = FMHY.Dom.el("div", { class: "fmhy-sidebar-list" });
    history.slice(0, 20).forEach((h, idx) => {
      const row = FMHY.Dom.el("a", {
        class: "fmhy-sidebar-list-item",
        href: h.url,
        target: "_blank",
        rel: "noopener",
        style: { animationDelay: `${idx * 30}ms` }
      });
      let host = "";
      try { host = new URL(h.url).hostname; } catch (e) {}
      const fav = host ? `https://www.google.com/s2/favicons?sz=32&domain=${host}` : "";
      const ago = FMHY.Dom.timeAgo(h.visitedAt);
      row.innerHTML = `
        ${fav ? `<img src="${fav}" alt="" width="20" height="20" onerror="this.style.visibility='hidden'">` : "<span>🕑</span>"}
        <div class="fmhy-sidebar-list-body">
          <div class="fmhy-sidebar-list-title"></div>
          <div class="fmhy-sidebar-list-sub">${ago} · ${host || "unknown"}</div>
        </div>
      `;
      row.querySelector(".fmhy-sidebar-list-title").textContent = h.title || h.url;
      list.appendChild(row);
    });
    sectionContent.appendChild(list);
  }

  /**
   * Show ratings list.
   */
  function showRatingsList(ratings) {
    if (!sectionContent) return;
    sectionContent.innerHTML = "";

    const entries = Object.entries(ratings);
    if (entries.length === 0) {
      const empty = FMHY.Dom.el("div", { class: "fmhy-sidebar-empty" });
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-icon" }, "⭐"));
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-text" }, "No ratings yet. Click the stars next to any resource."));
      sectionContent.appendChild(empty);
      return;
    }

    const backBtn = FMHY.Dom.el("button", { class: "fmhy-sidebar-back-btn" }, "‹ Back");
    backBtn.addEventListener("click", () => renderSection());
    sectionContent.appendChild(backBtn);

    const list = FMHY.Dom.el("div", { class: "fmhy-sidebar-list" });
    entries
      .sort((a, b) => b[1].stars - a[1].stars)
      .forEach(([url, r], idx) => {
        const row = FMHY.Dom.el("a", {
          class: "fmhy-sidebar-list-item",
          href: url,
          target: "_blank",
          rel: "noopener",
          style: { animationDelay: `${idx * 30}ms` }
        });
        row.innerHTML = `
          <span class="fmhy-sidebar-list-stars">${"⭐".repeat(r.stars)}</span>
          <div class="fmhy-sidebar-list-body">
            <div class="fmhy-sidebar-list-title"></div>
            <div class="fmhy-sidebar-list-sub">${r.review || "No review"}</div>
          </div>
          <button class="fmhy-sidebar-list-del" title="Delete rating">✕</button>
        `;
        let host = "";
        try { host = new URL(url).hostname; } catch (e) {}
        row.querySelector(".fmhy-sidebar-list-title").textContent = host || url;
        row.querySelector(".fmhy-sidebar-list-del").addEventListener("click", async (e) => {
          e.preventDefault();
          e.stopPropagation();
          await FMHY.Storage.removeRating(url);
          showToast("Rating deleted", "info");
          const updated = await FMHY.Storage.getRatings();
          showRatingsList(updated);
          refreshSavedBadges();
        });
        list.appendChild(row);
      });
    sectionContent.appendChild(list);
  }

  /**
   * Show notes list.
   */
  function showNotesList(notes) {
    if (!sectionContent) return;
    sectionContent.innerHTML = "";

    const entries = Object.entries(notes);
    if (entries.length === 0) {
      const empty = FMHY.Dom.el("div", { class: "fmhy-sidebar-empty" });
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-icon" }, "📝"));
      empty.appendChild(FMHY.Dom.el("div", { class: "fmhy-sidebar-empty-text" }, "No notes yet. Right-click any resource → Add note."));
      sectionContent.appendChild(empty);
      return;
    }

    const backBtn = FMHY.Dom.el("button", { class: "fmhy-sidebar-back-btn" }, "‹ Back");
    backBtn.addEventListener("click", () => renderSection());
    sectionContent.appendChild(backBtn);

    const list = FMHY.Dom.el("div", { class: "fmhy-sidebar-list" });
    entries
      .sort((a, b) => (b[1].updatedAt || 0) - (a[1].updatedAt || 0))
      .forEach(([url, n], idx) => {
        const row = FMHY.Dom.el("a", {
          class: "fmhy-sidebar-list-item",
          href: url,
          target: "_blank",
          rel: "noopener",
          style: { animationDelay: `${idx * 30}ms` }
        });
        const preview = (n.text || "").slice(0, 80) + ((n.text || "").length > 80 ? "…" : "");
        const ago = FMHY.Dom.timeAgo(n.updatedAt);
        row.innerHTML = `
          <span>📝</span>
          <div class="fmhy-sidebar-list-body">
            <div class="fmhy-sidebar-list-title"></div>
            <div class="fmhy-sidebar-list-sub">${ago} · ${preview}</div>
          </div>
          <button class="fmhy-sidebar-list-del" title="Delete note">✕</button>
        `;
        let host = "";
        try { host = new URL(url).hostname; } catch (e) {}
        row.querySelector(".fmhy-sidebar-list-title").textContent = host || url;
        row.querySelector(".fmhy-sidebar-list-del").addEventListener("click", async (e) => {
          e.preventDefault();
          e.stopPropagation();
          await FMHY.Storage.removeNote(url);
          showToast("Note deleted", "info");
          const updated = await FMHY.Storage.getNotes();
          showNotesList(updated);
          refreshSavedBadges();
        });
        list.appendChild(row);
      });
    sectionContent.appendChild(list);
  }

})(typeof globalThis !== "undefined" ? globalThis : (typeof self !== "undefined" ? self : this));
